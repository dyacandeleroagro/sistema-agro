import streamlit as st
import pandas as pd
import os
import datetime
from zoneinfo import ZoneInfo
import psycopg2
import os
import re
import hashlib
import time

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import (
    SimpleDocTemplate,
    Table,
    TableStyle,
    Paragraph,
    Spacer
)
from pwa.pwa import activar_pwa
from pages.ingresos import pantalla_ingresos
from pages.movimientos_bancarios import pantalla_movimientos_bancarios
from pages.clientes import pantalla_clientes
from pages.servicios import pantalla_servicios
from pages.campanas import pantalla_campanas
from pages.combustible import pantalla_combustible
from pages.agenda import pantalla_agenda
from pages.facturacion import pantalla_facturacion
from pages.mantenimiento import pantalla_mantenimiento
from pages.administracion import pantalla_administracion
from pages.panel_dueno import pantalla_panel_dueno
from database import get_conn
# Imports de seguros: se cargan dentro de la pestaña
from operaciones_db import (
    cargar_labores_desde_neon,
    guardar_labor_neon,
    actualizar_labor_neon,
    eliminar_labor_neon,
    cargar_combustible_desde_neon,
    cargar_ingresos_desde_neon,
)
from notificaciones import (
    mostrar_notificaciones,
    contar_notificaciones_no_leidas
)


def check_password(usuario, password):
    conn = get_conn()
    cur = conn.cursor()

    cur.execute("""
        SELECT nombre, rol, activo
        FROM usuarios
        WHERE usuario = %s
          AND password = %s
    """, (usuario, password))

    result = cur.fetchone()

    cur.close()
    conn.close()

    if result:
        nombre, rol, activo = result

        if not activo:
            return None, "DESHABILITADO"

        return nombre, rol.strip()

    return None, None

# ==========================================
# CONFIGURACIÓN DE LA INTERFAZ
# ==========================================
st.set_page_config(
    page_title="D&A Candelero Agro",
    layout="wide",
    page_icon="🚜"
)

activar_pwa()

st.markdown("""
    <style>
 .header-container {
        padding: 20px;
        border-radius: 12px;
        margin-bottom: 25px;
        border: 3px solid #1E4620;
    }
 .main-title { font-size: 30pt; font-weight: 900; color: #1E4620; }
 .subtitle { font-size: 14pt; color: #8B733A; font-weight: 700; margin-top: 5px; }
 .card-box {
        padding: 20px;
        border-radius: 10px;
        border: 2px solid #1E4620;
        margin-bottom: 15px;
        background-color: rgba(30, 70, 32, 0.05);
    }
 .card-title-custom { font-size: 11pt; font-weight: bold; text-transform: uppercase; }
 .card-value-custom { font-size: 22pt; font-weight: 900; color: #1E4620; margin-top: 5px; }
 .stButton>button {
        background-color: #1E4620!important;
        color: #FFFFFF!important;
        font-weight: bold!important;
        border-radius: 8px!important;
        border: 1px solid #1E4620!important;
        padding: 0.55rem 1rem!important;
        transition: all 0.15s ease-in-out;
    }
 .stButton>button:hover {
        background-color: #2D6530!important;
        border-color: #8B733A!important;
        transform: translateY(-1px);
    }
 .block-container { padding-top: 1.4rem; padding-bottom: 2.5rem; }
 div[data-testid="stMetric"] {
        background: rgba(30, 70, 32, 0.045);
        border: 1px solid rgba(30, 70, 32, 0.18);
        border-radius: 12px;
        padding: 14px 16px;
    }
 .stTabs [data-baseweb="tab-list"] { gap: 8px; }
 .stTabs [data-baseweb="tab"] { border-radius: 8px 8px 0 0; padding: 8px 14px; }
    </style>
""", unsafe_allow_html=True)

# ==========================================
# GESTIÓN DE USUARIOS REALES Y LOGIN
# ==========================================
if "autenticado" not in st.session_state:
    st.session_state["autenticado"] = False
    st.session_state["usuario"] = ""
    st.session_state["rol"] = ""
    st.session_state["nombre_usuario"] = ""

def formulario_login():
    st.markdown("<br><br>", unsafe_allow_html=True)
    col1, col2, col3 = st.columns([1, 2, 1])
    with col2:
        st.markdown('<div class="header-container" style="text-align: center;">', unsafe_allow_html=True)
        st.markdown('<div class="main-title" style="font-size: 22pt;">🔐 Acceso al Sistema</div>', unsafe_allow_html=True)
        st.markdown('<div class="subtitle">D&A Candelero Agro</div>', unsafe_allow_html=True)
        st.markdown('</div>', unsafe_allow_html=True)

        with st.form("login_form"):
            txt_user = st.text_input("Usuario (en minúsculas)").strip().lower()
            txt_pass = st.text_input("Contraseña", type="password").strip()
            btn_login = st.form_submit_button("Ingresar al Sistema")

            if btn_login:
                nombre, rol = check_password(txt_user, txt_pass)

                if rol == "DESHABILITADO":
                    st.error("⛔ Este usuario está deshabilitado. Contacte al administrador.")

                elif nombre:
                    st.session_state["autenticado"] = True
                    st.session_state["usuario"] = txt_user
                    st.session_state["rol"] = rol
                    st.session_state["nombre_usuario"] = nombre
                    st.success(f"¡Bienvenido {nombre}!")
                    st.rerun()

                else:
                    st.error("❌ Usuario o contraseña incorrectos.")
# ==========================================
# SI NO ESTA LOGUEADO MOSTRAR LOGIN
# ==========================================

if not st.session_state["autenticado"]:
    formulario_login()
    st.stop()
# ==========================================
# VERIFICACIÓN Y CARGA DE BASES DE DATOS (CSV)
# ==========================================
if not os.path.exists("comprobantes"):
    os.makedirs("comprobantes")

# ==========================================================
# CARGA DE GASTOS COMERCIALES DESDE NEON
# ==========================================================

columnas_facturas = {
    "ID": "",
    "Fecha Registro": "",
    "Proveedor": "",
    "Monto Original": 0.0,
    "Moneda": "ARS",
    "Monto (ARS)": 0.0,
    "Categoría": "",
    "Lote Asignado": "",
    "Estado Pago": "",
    "Archivo Comprobante": ""
}


def cargar_gastos_desde_neon():

    try:

        conn = get_conn()

        query = """
            SELECT
                id_gasto,
                fecha_registro,
                proveedor,
                monto_original,
                moneda,
                monto_ars,
                categoria,
                lote_asignado,
                estado_pago,
                archivo_comprobante
            FROM gastos_comerciales
            ORDER BY fecha_registro, id_gasto
        """

        df = pd.read_sql_query(
            query,
            conn
        )

        conn.close()

        if df.empty:
            return pd.DataFrame()

        df = df.rename(
            columns={
                "id_gasto": "ID",
                "fecha_registro": "Fecha Registro",
                "proveedor": "Proveedor",
                "monto_original": "Monto Original",
                "moneda": "Moneda",
                "monto_ars": "Monto (ARS)",
                "categoria": "Categoría",
                "lote_asignado": "Lote Asignado",
                "estado_pago": "Estado Pago",
                "archivo_comprobante": "Archivo Comprobante"
            }
        )

        return df

    except Exception as e:

        st.warning(
            f"⚠️ No se pudieron cargar los gastos desde Neon: {e}"
        )

        return pd.DataFrame()


# ==========================================================
# CARGAR GASTOS
# ==========================================================

df_facturas = cargar_gastos_desde_neon()


# ==========================================================
# RESPALDO / MIGRACIÓN DESDE CSV
# ==========================================================

if (
    df_facturas.empty
    and os.path.exists("datos_facturas.csv")
):

    df_csv_facturas = pd.read_csv(
        "datos_facturas.csv"
    )

    if not df_csv_facturas.empty:

        for columna, valor in columnas_facturas.items():

            if columna not in df_csv_facturas.columns:

                df_csv_facturas[columna] = valor

        df_facturas = df_csv_facturas.copy()


# ==========================================================
# ASEGURAR COLUMNAS
# ==========================================================

for columna, valor in columnas_facturas.items():

    if columna not in df_facturas.columns:

        df_facturas[columna] = valor


# ==========================================================
# ASEGURAR ID COMO TEXTO
# ==========================================================

df_facturas["ID"] = (
    df_facturas["ID"]
    .fillna("")
    .astype(str)
)

# ==========================================================
# GUARDAR GASTO EN NEON
# ==========================================================

def guardar_gasto_en_neon(gasto, comprobante_data=None):

    conn = None
    cursor = None

    try:

        conn = get_conn()
        cursor = conn.cursor()

        query = """
            INSERT INTO gastos_comerciales (
                id_gasto,
                fecha_registro,
                proveedor,
                monto_original,
                moneda,
                monto_ars,
                categoria,
                lote_asignado,
                estado_pago,
                archivo_comprobante,
                comprobante_data
            )
            VALUES (
                %s, %s, %s, %s, %s,
                %s, %s, %s, %s, %s, %s
            )
        """

        valores = (
            str(gasto.get("ID", "")),
            gasto.get("Fecha Registro") or None,
            gasto.get("Proveedor", ""),
            float(gasto.get("Monto Original", 0) or 0),
            gasto.get("Moneda", "ARS"),
            float(gasto.get("Monto (ARS)", 0) or 0),
            gasto.get("Categoría", ""),
            gasto.get("Lote Asignado", ""),
            gasto.get("Estado Pago", ""),
            gasto.get("Archivo Comprobante", ""),
            comprobante_data
        )

        cursor.execute(query, valores)
        conn.commit()

        return True

    except Exception as e:

        if conn:
            conn.rollback()

        st.error(
            f"❌ Error guardando gasto en Neon: {e}"
        )

        return False

    finally:

        if cursor:
            cursor.close()

        if conn:
            conn.close()



# Las labores y las cargas de combustible se leen desde Neon para que
# permanezcan disponibles después de reinicios o nuevas implementaciones.
df_telemetria = cargar_labores_desde_neon()
df_combustible = cargar_combustible_desde_neon()

if not os.path.exists("registro_empleados.csv"):
    df_inicial_emp = pd.DataFrame([
        {"Nombre": "Damian Acosta", "Puesto": "Tractorista", "Porcentaje (%)": 0.0},
        {"Nombre": "German Posseto", "Puesto": "Maquinista Cosechadora", "Porcentaje (%)": 0.0},
        {"Nombre": "Gonzalo Vega", "Puesto": "Tractorista", "Porcentaje (%)": 0.0}
    ])
    df_inicial_emp.to_csv("registro_empleados.csv", index=False)
# ==========================================================
# CARGAR EMPLEADOS DESDE NEON
# ==========================================================

try:

    conn_empleados = get_conn()

    df_empleados = pd.read_sql(
        """
        SELECT
            nombre AS "Nombre",
            puesto AS "Puesto",
            porcentaje AS "Porcentaje (%)"
        FROM empleados
        ORDER BY nombre
        """,
        conn_empleados
    )

    conn_empleados.close()

except Exception:

    # Respaldo: si Neon no está disponible,
    # usar el CSV local

    if os.path.exists("registro_empleados.csv"):

        df_empleados = pd.read_csv(
            "registro_empleados.csv",
            encoding="utf-8-sig"
        )

    else:

        df_empleados = pd.DataFrame(
            columns=[
                "Nombre",
                "Puesto",
                "Porcentaje (%)"
            ]
        )

if not os.path.exists("registro_pagos_empleados.csv"):

    pd.DataFrame(columns=[
        "ID_Pago",
        "Fecha Pago",
        "Nombre Empleado",
        "Fecha Trabajo",
        "Hora Entrada",
        "Hora Salida",
        "Horas Trabajadas",
        "Valor Hora",
        "Monto (ARS)",
        "Tipo Registro",
        "Estado Pago",
        "Concepto"
    ]).to_csv(
        "registro_pagos_empleados.csv",
        index=False
    )

ARCHIVO_PAGOS_EMPLEADOS = "registro_pagos_empleados.csv"

# ==========================================================
# CARGA DE PAGOS DE EMPLEADOS DESDE NEON
# ==========================================================

columnas_pagos = {
    "ID_Pago": "",
    "Fecha Pago": "",
    "Nombre Empleado": "",
    "Fecha Trabajo": "",
    "Hora Entrada": "",
    "Hora Salida": "",
    "Horas Trabajadas": 0.0,
    "Valor Hora": 0.0,
    "Monto (ARS)": 0.0,
    "Tipo Registro": "",
    "Estado Pago": "",
    "Concepto": "",
    "Porcentaje Bonificacion": 0.0,
    "Monto Bonificacion (ARS)": 0.0,
    "Porcentaje Descuento": 0.0,
    "Monto Descuento (ARS)": 0.0,
    "Monto Trabajado (ARS)": 0.0,
    "Monto Pagado (ARS)": 0.0,
    "Monto Final Trabajo (ARS)": 0.0,
    "Adelanto Generado (ARS)": 0.0,
    "Monto Compensado (ARS)": 0.0,
    "Saldo Adelanto (ARS)": 0.0,
    "Saldo Pendiente Pago (ARS)": 0.0,
    "Comprobantes": "",
    "PDF Liquidacion": ""
}


def cargar_pagos_desde_neon():

    try:

        conn = get_conn()

        query = """
            SELECT
                id_pago,
                fecha_pago,
                nombre_empleado,
                fecha_trabajo,
                hora_entrada,
                hora_salida,
                horas_trabajadas,
                valor_hora,
                monto_ars,
                tipo_registro,
                estado_pago,
                concepto,
                porcentaje_bonificacion,
                monto_bonificacion,
                porcentaje_descuento,
                monto_descuento,
                monto_trabajado_ars,
                monto_pagado_ars,
                monto_final_trabajo_ars,
                adelanto_generado_ars,
                monto_compensado_ars,
                saldo_adelanto_ars,
                saldo_pendiente_pago_ars,
                comprobantes,
                pdf_liquidacion
            FROM pagos_empleados
            ORDER BY fecha_pago, id
        """

        df = pd.read_sql_query(
            query,
            conn
        )

        conn.close()

        if df.empty:

            return pd.DataFrame()

        df = df.rename(
            columns={
                "id_pago": "ID_Pago",
                "fecha_pago": "Fecha Pago",
                "nombre_empleado": "Nombre Empleado",
                "fecha_trabajo": "Fecha Trabajo",
                "hora_entrada": "Hora Entrada",
                "hora_salida": "Hora Salida",
                "horas_trabajadas": "Horas Trabajadas",
                "valor_hora": "Valor Hora",
                "monto_ars": "Monto (ARS)",
                "tipo_registro": "Tipo Registro",
                "estado_pago": "Estado Pago",
                "concepto": "Concepto",
                "porcentaje_bonificacion": "Porcentaje Bonificacion",
                "monto_bonificacion": "Monto Bonificacion (ARS)",
                "porcentaje_descuento": "Porcentaje Descuento",
                "monto_descuento": "Monto Descuento (ARS)",
                "monto_trabajado_ars": "Monto Trabajado (ARS)",
                "monto_pagado_ars": "Monto Pagado (ARS)",
                "monto_final_trabajo_ars": "Monto Final Trabajo (ARS)",
                "adelanto_generado_ars": "Adelanto Generado (ARS)",
                "monto_compensado_ars": "Monto Compensado (ARS)",
                "saldo_adelanto_ars": "Saldo Adelanto (ARS)",
                "saldo_pendiente_pago_ars": "Saldo Pendiente Pago (ARS)",
                "comprobantes": "Comprobantes",
                "pdf_liquidacion": "PDF Liquidacion"
            }
        )

        return df

    except Exception as e:

        st.warning(
            f"⚠️ No se pudo cargar pagos desde Neon: {e}"
        )

        return pd.DataFrame()


# ==========================================================
# CARGAR PAGOS
# ==========================================================

df_pagos_empleados = cargar_pagos_desde_neon()


# ==========================================================
# RESPALDO / MIGRACIÓN AUTOMÁTICA DESDE CSV
# ==========================================================

if (
    df_pagos_empleados.empty
    and os.path.exists(ARCHIVO_PAGOS_EMPLEADOS)
):

    df_csv_pagos = pd.read_csv(
        ARCHIVO_PAGOS_EMPLEADOS,
        encoding="utf-8-sig"
    )

    if not df_csv_pagos.empty:

        for columna, valor in columnas_pagos.items():

            if columna not in df_csv_pagos.columns:

                df_csv_pagos[columna] = valor

        df_pagos_empleados = df_csv_pagos.copy()


# ==========================================================
# ASEGURAR COLUMNAS
# ==========================================================

for columna, valor in columnas_pagos.items():

    if columna not in df_pagos_empleados.columns:

        df_pagos_empleados[columna] = valor


# ==========================================================
# ASEGURAR ID COMO TEXTO
# ==========================================================

df_pagos_empleados["ID_Pago"] = (
    df_pagos_empleados["ID_Pago"]
    .fillna("")
    .astype(str)
)

# ==========================================================
# FUNCIONES - MI JORNADA
# ==========================================================

def obtener_jornada_hoy(nombre_empleado):

    conn = None
    cursor = None

    try:

        conn = get_conn()
        cursor = conn.cursor()

        cursor.execute(
            """
            SELECT
                id,
                nombre_empleado,
                fecha,
                entrada_manana,
                salida_manana,
                entrada_tarde,
                salida_tarde,
                horas_manana,
                horas_tarde,
                horas_totales,
                estado
            FROM jornadas_empleados
            WHERE nombre_empleado = %s
              AND fecha = CURRENT_DATE
            LIMIT 1
            """,
            (nombre_empleado,)
        )

        fila = cursor.fetchone()

        if fila is None:
            return None

        columnas = [
            "id",
            "nombre_empleado",
            "fecha",
            "entrada_manana",
            "salida_manana",
            "entrada_tarde",
            "salida_tarde",
            "horas_manana",
            "horas_tarde",
            "horas_totales",
            "estado"
        ]

        return dict(zip(columnas, fila))

    except Exception as e:

        st.error(
            f"❌ Error leyendo jornada: {e}"
        )

        return None

    finally:

        if cursor:
            cursor.close()

        if conn:
            conn.close()


def crear_jornada_hoy(nombre_empleado):

    conn = None
    cursor = None

    try:

        conn = get_conn()
        cursor = conn.cursor()

        cursor.execute(
            """
            INSERT INTO jornadas_empleados (
                nombre_empleado,
                fecha,
                horas_manana,
                horas_tarde,
                horas_totales,
                estado
            )
            VALUES (
                %s,
                CURRENT_DATE,
                0,
                0,
                0,
                'abierto'
            )
            ON CONFLICT (
                nombre_empleado,
                fecha
            )
            DO NOTHING
            """,
            (nombre_empleado,)
        )

        conn.commit()

        return True

    except Exception as e:

        if conn:
            conn.rollback()

        st.error(
            f"❌ Error creando jornada: {e}"
        )

        return False

    finally:

        if cursor:
            cursor.close()

        if conn:
            conn.close()


def actualizar_jornada_empleado(
    nombre_empleado,
    campo,
    valor
):

    campos_permitidos = {
        "entrada_manana",
        "salida_manana",
        "entrada_tarde",
        "salida_tarde",
        "horas_manana",
        "horas_tarde",
        "horas_totales",
        "estado"
    }

    if campo not in campos_permitidos:
        return False

    conn = None
    cursor = None

    try:

        conn = get_conn()
        cursor = conn.cursor()

        query = f"""
            UPDATE jornadas_empleados
            SET
                {campo} = %s,
                actualizado_en = CURRENT_TIMESTAMP
            WHERE nombre_empleado = %s
              AND fecha = CURRENT_DATE
        """

        cursor.execute(
            query,
            (
                valor,
                nombre_empleado
            )
        )

        conn.commit()

        return True

    except Exception as e:

        if conn:
            conn.rollback()

        st.error(
            f"❌ Error actualizando jornada: {e}"
        )

        return False

    finally:

        if cursor:
            cursor.close()

        if conn:
            conn.close()


def calcular_horas_jornada(
    entrada,
    salida
):

    if not entrada or not salida:
        return 0.0

    diferencia = salida - entrada

    segundos = diferencia.total_seconds()

    if segundos <= 0:
        return 0.0

    return round(
        segundos / 3600,
        2
    )

def obtener_horas_jornada_periodo(nombre_empleado, fecha_desde, fecha_hasta):
    conn = None
    cursor = None

    try:

        conn = get_conn()
        cursor = conn.cursor()

        cursor.execute(
            """
            SELECT COALESCE(SUM(j.horas_totales), 0)
            FROM jornadas_empleados j
            LEFT JOIN jornadas_liquidadas jl
                ON jl.id_jornada = j.id
            WHERE j.nombre_empleado = %s
              AND j.fecha >= %s
              AND j.fecha <= %s
              AND jl.id_jornada IS NULL
              AND j.estado <> 'cancelado'
            """,
            (
                nombre_empleado,
                fecha_desde,
                fecha_hasta
            )
        )

        resultado = cursor.fetchone()

        if resultado and resultado[0] is not None:

            return float(
                resultado[0]
            )

        return 0.0

    except Exception as e:

        st.error(
            f"❌ Error obteniendo horas pendientes: {e}"
        )

        return 0.0

    finally:

        if cursor:
            cursor.close()

        if conn:
            conn.close()
# ==========================================================
# HORAS PENDIENTES DE PAGO
# ==========================================================

def obtener_horas_pendientes_empleado(
    nombre_empleado
):

    conn = None
    cursor = None

    try:

        conn = get_conn()
        cursor = conn.cursor()

        cursor.execute(
            """
            SELECT
                COALESCE(
                    SUM(j.horas_totales),
                    0
                )
            FROM jornadas_empleados j
            LEFT JOIN jornadas_liquidadas jl
                ON jl.id_jornada = j.id
            WHERE j.nombre_empleado = %s
              AND jl.id_jornada IS NULL
              AND j.estado <> 'cancelado'
            """,
            (nombre_empleado,)
        )

        resultado = cursor.fetchone()

        if resultado and resultado[0] is not None:

            return float(
                resultado[0]
            )

        return 0.0

    except Exception as e:

        st.error(
            f"❌ Error obteniendo horas pendientes: {e}"
        )

        return 0.0

    finally:

        if cursor:
            cursor.close()

        if conn:
            conn.close()


# ==========================================================
# OBTENER JORNADAS PENDIENTES
# ==========================================================

def obtener_jornadas_pendientes_empleado(
    nombre_empleado
):

    conn = None
    cursor = None

    try:

        conn = get_conn()
        cursor = conn.cursor()

        cursor.execute(
            """
            SELECT
                j.id,
                j.fecha,
                j.entrada_manana,
                j.salida_manana,
                j.entrada_tarde,
                j.salida_tarde,
                j.horas_manana,
                j.horas_tarde,
                j.horas_totales,
                j.estado
            FROM jornadas_empleados j
            LEFT JOIN jornadas_liquidadas jl
                ON jl.id_jornada = j.id
            WHERE j.nombre_empleado = %s
              AND jl.id_jornada IS NULL
              AND j.estado <> 'cancelado'
            ORDER BY j.fecha ASC
            """,
            (nombre_empleado,)
        )

        filas = cursor.fetchall()

        columnas = [
            "id",
            "fecha",
            "entrada_manana",
            "salida_manana",
            "entrada_tarde",
            "salida_tarde",
            "horas_manana",
            "horas_tarde",
            "horas_totales",
            "estado"
        ]

        return [
            dict(zip(columnas, fila))
            for fila in filas
        ]

    except Exception as e:

        st.error(
            f"❌ Error obteniendo jornadas pendientes: {e}"
        )

        return []

    finally:

        if cursor:
            cursor.close()

        if conn:
            conn.close()


# ==========================================================
# MARCAR JORNADAS COMO LIQUIDADAS
# ==========================================================

def marcar_jornadas_como_liquidadas(
    nombre_empleado,
    id_pago
):

    conn = None
    cursor = None

    try:

        conn = get_conn()
        cursor = conn.cursor()

        cursor.execute(
            """
            INSERT INTO jornadas_liquidadas (
                id_jornada,
                id_pago
            )
            SELECT
                j.id,
                %s
            FROM jornadas_empleados j
            LEFT JOIN jornadas_liquidadas jl
                ON jl.id_jornada = j.id
            WHERE j.nombre_empleado = %s
              AND jl.id_jornada IS NULL
              AND j.estado <> 'cancelado'
            """,
            (
                str(id_pago),
                nombre_empleado
            )
        )

        conn.commit()

        return True

    except Exception as e:

        if conn:
            conn.rollback()

        st.error(
            f"❌ Error marcando jornadas como pagadas: {e}"
        )

        return False

    finally:

        if cursor:
            cursor.close()

        if conn:
            conn.close()            

# ==========================================================
# GUARDAR PAGO EN NEON
# ==========================================================

def guardar_pago_en_neon(pago):

    conn = None
    cursor = None

    try:

        conn = get_conn()
        cursor = conn.cursor()

        # ==================================================
        # BUSCAR EL PDF GENERADO PARA GUARDARLO EN NEON
        # ==================================================

        pdf_data = None

        ruta_pdf = str(
            pago.get("PDF Liquidacion", "")
            or ""
        ).strip()

        # Si la ruta está guardada y el archivo existe
        if ruta_pdf and os.path.exists(ruta_pdf):

            with open(
                ruta_pdf,
                "rb"
            ) as archivo_pdf:

                pdf_data = archivo_pdf.read()

        # Si no encontramos la ruta, intentar por ID
        if pdf_data is None:

            id_pago_pdf = str(
                pago.get("ID_Pago", "")
            ).strip()

            ruta_pdf_alternativa = os.path.join(
                "liquidaciones_pdf",
                f"liquidacion_{id_pago_pdf}.pdf"
            )

            if os.path.exists(
                ruta_pdf_alternativa
            ):

                with open(
                    ruta_pdf_alternativa,
                    "rb"
                ) as archivo_pdf:

                    pdf_data = archivo_pdf.read()

        # ==================================================
        # GUARDAR PAGO + PDF EN NEON
        # ==================================================

        query = """
            INSERT INTO pagos_empleados (
                id_pago,
                fecha_pago,
                nombre_empleado,
                fecha_trabajo,
                hora_entrada,
                hora_salida,
                horas_trabajadas,
                valor_hora,
                monto_ars,
                tipo_registro,
                estado_pago,
                concepto,
                porcentaje_bonificacion,
                monto_bonificacion,
                porcentaje_descuento,
                monto_descuento,
                monto_trabajado_ars,
                monto_pagado_ars,
                monto_final_trabajo_ars,
                adelanto_generado_ars,
                monto_compensado_ars,
                saldo_adelanto_ars,
                saldo_pendiente_pago_ars,
                comprobantes,
                pdf_liquidacion,
                pdf_liquidacion_data
            )
            VALUES (
                %s, %s, %s, %s, %s,
                %s, %s, %s, %s, %s,
                %s, %s, %s, %s, %s,
                %s, %s, %s, %s, %s,
                %s, %s, %s, %s, %s,
                %s
            )
        """

        valores = (
            str(
                pago.get(
                    "ID_Pago",
                    ""
                )
            ),

            pago.get(
                "Fecha Pago"
            ) or None,

            pago.get(
                "Nombre Empleado",
                ""
            ),

            pago.get(
                "Fecha Trabajo",
                ""
            ),

            pago.get(
                "Hora Entrada",
                ""
            ),

            pago.get(
                "Hora Salida",
                ""
            ),

            float(
                pago.get(
                    "Horas Trabajadas",
                    0
                ) or 0
            ),

            float(
                pago.get(
                    "Valor Hora",
                    0
                ) or 0
            ),

            float(
                pago.get(
                    "Monto (ARS)",
                    0
                ) or 0
            ),

            pago.get(
                "Tipo Registro",
                ""
            ),

            pago.get(
                "Estado Pago",
                ""
            ),

            pago.get(
                "Concepto",
                ""
            ),

            float(
                pago.get(
                    "Porcentaje Bonificacion",
                    0
                ) or 0
            ),

            float(
                pago.get(
                    "Monto Bonificacion (ARS)",
                    0
                ) or 0
            ),

            float(
                pago.get(
                    "Porcentaje Descuento",
                    0
                ) or 0
            ),

            float(
                pago.get(
                    "Monto Descuento (ARS)",
                    0
                ) or 0
            ),

            float(
                pago.get(
                    "Monto Trabajado (ARS)",
                    0
                ) or 0
            ),

            float(
                pago.get(
                    "Monto Pagado (ARS)",
                    0
                ) or 0
            ),

            float(
                pago.get(
                    "Monto Final Trabajo (ARS)",
                    0
                ) or 0
            ),

            float(
                pago.get(
                    "Adelanto Generado (ARS)",
                    0
                ) or 0
            ),

            float(
                pago.get(
                    "Monto Compensado (ARS)",
                    0
                ) or 0
            ),

            float(
                pago.get(
                    "Saldo Adelanto (ARS)",
                    0
                ) or 0
            ),

            float(
                pago.get(
                    "Saldo Pendiente Pago (ARS)",
                    0
                ) or 0
            ),

            pago.get(
                "Comprobantes",
                ""
            ),

            pago.get(
                "PDF Liquidacion",
                ""
            ),

            pdf_data
        )

        cursor.execute(
            query,
            valores
        )

        # ==================================================
        # MARCAR JORNADAS COMO LIQUIDADAS
        # SOLAMENTE EN LIQUIDACIÓN ESPECIAL PAGADA
        # ==================================================

        liquidar_jornadas = (
            pago.get(
                "Liquidar Jornadas",
                False
            )
            is True
        )

        estado_pago = str(
            pago.get(
                "Estado Pago",
                ""
            )
        ).strip()

        tipo_registro = str(
            pago.get(
                "Tipo Registro",
                ""
            )
        ).strip()

        nombre_empleado = str(
            pago.get(
                "Nombre Empleado",
                ""
            )
        ).strip()

        fecha_desde = pago.get(
            "Fecha Desde Jornadas"
        )

        fecha_hasta = pago.get(
            "Fecha Hasta Jornadas"
        )

        id_pago = str(
            pago.get(
                "ID_Pago",
                ""
            )
        ).strip()

        if (
            liquidar_jornadas
            and estado_pago == "Pagado"
            and tipo_registro == "Liquidación / Pago"
            and nombre_empleado
            and id_pago
            and fecha_desde
            and fecha_hasta
        ):

            cursor.execute(
                """
                INSERT INTO jornadas_liquidadas (
                    id_jornada,
                    id_pago
                )
                SELECT
                    j.id,
                    %s
                FROM jornadas_empleados j
                LEFT JOIN jornadas_liquidadas jl
                    ON jl.id_jornada = j.id
                WHERE j.nombre_empleado = %s
                  AND j.fecha >= %s
                  AND j.fecha <= %s
                  AND jl.id_jornada IS NULL
                  AND j.estado <> 'cancelado'
                """,
                (
                    id_pago,
                    nombre_empleado,
                    fecha_desde,
                    fecha_hasta
                )
            )

        # ==================================================
        # CONFIRMAR TODO EN UNA SOLA TRANSACCIÓN
        # ==================================================

        conn.commit()

        return True

    except Exception as e:

        if conn:
            conn.rollback()

        st.error(
            f"❌ Error guardando el pago en Neon: {e}"
        )

        return False

    finally:

        if cursor:
            cursor.close()

        if conn:
            conn.close()
            
if not os.path.exists("registro_ingresos.csv"):
    pd.DataFrame(columns=["ID_Ingreso", "Fecha", "Cliente", "Tipo Servicio", "Lote/Establecimiento", "Hectáreas", "Monto Total (ARS)", "Detalle"]).to_csv("registro_ingresos.csv", index=False)
df_ingresos = pd.read_csv("registro_ingresos.csv")
df_ingresos["ID_Ingreso"] = df_ingresos["ID_Ingreso"].astype(str)

if not os.path.exists("registro_seguros.csv"):
    pd.DataFrame(columns=["ID_Seguro", "Compañía", "Tipo Cobertura", "Bien Asegurado", "Vencimiento", "Monto Prima (ARS)", "Estado Pago"]).to_csv("registro_seguros.csv", index=False)
df_seguros = pd.read_csv("registro_seguros.csv")
df_seguros["ID_Seguro"] = df_seguros["ID_Seguro"].astype(str)

TIPO_CAMBIO_OFICIAL = 950.0

# ==========================================
# ENCABEZADO PRINCIPAL (CON LOGOUT)
# ==========================================
st.markdown('<div class="header-container">', unsafe_allow_html=True)
col_logo, col_titulo, col_user = st.columns([1, 3, 1])
with col_logo:
    ruta_logo = "logo.png" if os.path.exists("logo.png") else (
        "static/logo.png" if os.path.exists("static/logo.png") else None
    )
    if ruta_logo:
        st.image(ruta_logo, width=130)
    else:
        st.markdown("<h1 style='font-size: 40pt; margin: 0;'>🚜</h1>", unsafe_allow_html=True)
with col_titulo:
    st.markdown('<div class="main-title">D&A CANDELERO AGRO</div>', unsafe_allow_html=True)
    st.markdown(f'<div class="subtitle">Sesión iniciada: <b>{st.session_state["nombre_usuario"]}</b> ({st.session_state["rol"]})</div>', unsafe_allow_html=True)
with col_user:
    st.markdown("<br>", unsafe_allow_html=True)
    if st.button("🚪 Cerrar Sesión", key="btn_logout"):
        st.session_state["autenticado"] = False
        st.session_state["usuario"] = ""
        st.session_state["rol"] = ""
        st.session_state["nombre_usuario"] = ""
        st.rerun()
st.markdown('</div>', unsafe_allow_html=True)

# ==========================================
# CONFIGURACIÓN FILTRADA DE PESTAÑAS POR ROL
# ==========================================
rol_actual = st.session_state["rol"]
nombre_actual = st.session_state["nombre_usuario"]

# ===============================
# ROLES DEL USUARIO
# ===============================

roles_usuario = [
    r.strip()
    for r in rol_actual.split(",")
    if r.strip()
]

def tiene_rol(*roles):
    return any(r in roles_usuario for r in roles)

# Si está deshabilitado y NO es dueño
if (
    "Deshabilitado" in roles_usuario
    and
    "Dueño" not in roles_usuario
):
    st.error("⛔ Este usuario está deshabilitado.")
    st.stop()

opciones_menu = []

if rol_actual == "Dueño":

    opciones = [
        "📈 ANALÍTICAS CENTRALES",
        "🚜 LABORES Y LOTES",
        "💰 INGRESOS POR TRABAJOS",
        "🧾 GASTOS COMERCIALES",
        "🔍 CUENTAS PENDIENTES",
        "👥 SISTEMA DE TRIPULACIÓN",
        "📋 RENDICIÓN POR OPERARIO",
        "👥 CLIENTES",
        "🧾 FACTURACIÓN",
        "🛠 SERVICIOS",
        "⚙ ADMINISTRACIÓN",
        "🛡 SEGUROS Y COBERTURAS",
        "🗄 CONTROL DE ERRORES"
    ]

elif rol_actual == "Administrador":

    opciones = [
        "📈 ANALÍTICAS CENTRALES",
        "🚜 LABORES Y LOTES",
        "💰 INGRESOS POR TRABAJOS",
        "🧾 GASTOS COMERCIALES",
        "🔍 CUENTAS PENDIENTES",
        "👥 SISTEMA DE TRIPULACIÓN",
        "📋 RENDICIÓN POR OPERARIO",
        "👥 CLIENTES",
        "🧾 FACTURACIÓN",
        "🛠 SERVICIOS",
        "⚙ ADMINISTRACIÓN",
        "🛡 SEGUROS Y COBERTURAS"
    ]

else:

    opciones = [
        "🚜 LABORES Y LOTES",
        "📋 RENDICIÓN POR OPERARIO"
    ]

opciones = []

if tiene_rol("Dueño","Administrador","Contador"):
    opciones.append("📈 ANALÍTICAS CENTRALES")

if tiene_rol("Dueño","Administrador","Encargado","Operario","Maquinista"):
    opciones.append("🚜 LABORES Y LOTES")

if tiene_rol("Dueño","Administrador","Contador"):
    opciones.append("💰 INGRESOS POR TRABAJOS")

if tiene_rol("Dueño","Administrador","Contador"):
    opciones.append("🧾 GASTOS COMERCIALES")

if tiene_rol("Dueño","Administrador","Contador"):
    opciones.append("🏦 MOVIMIENTOS BANCARIOS")

if tiene_rol("Dueño","Administrador","Contador"):
    opciones.append("🔍 CUENTAS PENDIENTES")

if tiene_rol("Dueño","Administrador","Encargado"):
    opciones.append("👥 SISTEMA DE TRIPULACIÓN")

if tiene_rol("Operario", "Maquinista","Encargado" ):
    opciones.append("🕐 MI JORNADA")

if tiene_rol("Dueño", "Administrador"):
    opciones.append("🖥️ CONSOLA TRIPULACIÓN")        

if tiene_rol("Dueño","Administrador","Encargado","Operario","Maquinista"):
    opciones.append("📋 RENDICIÓN POR OPERARIO")

if tiene_rol("Dueño","Administrador","Contador"):
    opciones.append("👥 CLIENTES")

if tiene_rol("Dueño","Administrador","Contador"):
    opciones.append("🧾 FACTURACIÓN")

if tiene_rol("Dueño","Administrador"):
    opciones.append("🛠 SERVICIOS")

if tiene_rol("Dueño","Administrador","Encargado"):
    opciones.append("🌱 CAMPAÑAS AGRÍCOLAS")

if tiene_rol("Dueño","Administrador","Encargado"):
    opciones.append("🔧 MANTENIMIENTO DE MAQUINARIA")

if tiene_rol("Dueño","Administrador","Encargado","Operario"):
    opciones.append("⛽ CONTROL DE COMBUSTIBLE")

if tiene_rol(
    "Dueño",
    "Administrador",
    "Encargado",
    "Contador",
    "Operario",
    "Maquinista"
):
    opciones.append("📅 AGENDA Y VENCIMIENTOS")

if tiene_rol("Dueño","Administrador"):
    opciones.append("⚙ ADMINISTRACIÓN")

if tiene_rol("Dueño","Administrador"):
    opciones.append("🛡 SEGUROS Y COBERTURAS")

if tiene_rol("Dueño"):
    opciones.append("🗄 CONTROL DE ERRORES")

if tiene_rol("Dueño"):
    opciones.append("👑 PANEL DEL DUEÑO")

# ==========================================
# NOTIFICACIONES
# ==========================================

opciones.append(
    "🔔 NOTIFICACIONES"
)

menu = st.sidebar.radio(
    "📂 Menú",
    opciones
)

# ==========================================================
# 🕐 MI JORNADA
# ==========================================================

if menu == "🕐 MI JORNADA":

    st.header("🕐 Mi Jornada")

    nombre_empleado = st.session_state.get(
        "nombre_usuario",
        ""
    )

    if not nombre_empleado:

        st.error(
            "❌ No se pudo identificar al empleado."
        )

    else:

        # ==================================================
        # OBTENER / CREAR JORNADA DEL DÍA
        # ==================================================

        jornada = obtener_jornada_hoy(
            nombre_empleado
        )

        if jornada is None:

            crear_jornada_hoy(
                nombre_empleado
            )

            jornada = obtener_jornada_hoy(
                nombre_empleado
            )

        ahora = datetime.datetime.now(
            ZoneInfo("America/Argentina/Buenos_Aires")
        ).replace(tzinfo=None)

        # ==================================================
        # CIERRE AUTOMÁTICO DE LA MAÑANA A LAS 12:00
        # ==================================================

        if (
            jornada
            and jornada["entrada_manana"]
            and not jornada["salida_manana"]
        ):

            fecha_jornada = jornada["fecha"]

            cierre_manana = datetime.datetime.combine(
                fecha_jornada,
                datetime.time(12, 0)
            )

            if ahora >= cierre_manana:

                horas_manana = calcular_horas_jornada(
                    jornada["entrada_manana"],
                    cierre_manana
                )

                actualizar_jornada_empleado(
                    nombre_empleado,
                    "salida_manana",
                    cierre_manana
                )

                actualizar_jornada_empleado(
                    nombre_empleado,
                    "horas_manana",
                    horas_manana
                )

                jornada = obtener_jornada_hoy(
                    nombre_empleado
                )

        # ==================================================
        # CABECERA
        # ==================================================

        st.subheader(
            f"👷 {nombre_empleado}"
        )

        st.caption(
            f"Fecha: {datetime.date.today().strftime('%d/%m/%Y')}"
        )

        st.markdown("---")

        # ==================================================
        # MAÑANA
        # ==================================================

        st.markdown("### 🌅 Jornada de la mañana")

        col_manana_1, col_manana_2 = st.columns(2)

                # --------------------------------------------------
        # ENTRADA MAÑANA
        # --------------------------------------------------

        with col_manana_1:

            if jornada["entrada_manana"]:

                st.success(
                    "🟢 Entrada registrada"
                )

                st.write(
                    "Hora de entrada:",
                    jornada[
                        "entrada_manana"
                    ].strftime("%H:%M:%S")
                )

            else:

                if (
                    ahora >= datetime.datetime.combine(
                        datetime.date.today(),
                        datetime.time(8, 0)
                    )
                    and
                    ahora < datetime.datetime.combine(
                        datetime.date.today(),
                        datetime.time(12, 0)
                    )
                ):

                    if st.button(
                        "🟢 ENTRÉ A TRABAJAR",
                        use_container_width=True,
                        key="btn_mi_jornada_entrada_manana"
                    ):

                        momento = datetime.datetime.now(
                            ZoneInfo(
                                "America/Argentina/Buenos_Aires"
                            )
                        ).replace(tzinfo=None)

                        actualizar_jornada_empleado(
                            nombre_empleado,
                            "entrada_manana",
                            momento
                        )

                        st.success(
                            "✅ Entrada registrada correctamente."
                        )

                        st.rerun()

                elif ahora < datetime.datetime.combine(
                    datetime.date.today(),
                    datetime.time(8, 0)
                ):

                    st.info(
                        "⏰ La jornada de mañana se habilita a las 08:00."
                    )

                else:

                    st.info(
                        "🌅 No se registraron horas de mañana."
                    )

        # --------------------------------------------------
        # SALIDA MAÑANA
        # --------------------------------------------------
        
        with col_manana_2:

            if jornada["salida_manana"]:

                st.success(
                    "🔴 Mañana cerrada"
                )

                st.write(
                    "Hora de salida:",
                    jornada[
                        "salida_manana"
                    ].strftime("%H:%M:%S")
                )

                st.write(
                    f"⏱️ Horas mañana: "
                    f"**{float(jornada['horas_manana'] or 0):.2f} h**"
                )

            elif jornada["entrada_manana"]:

                if ahora < datetime.datetime.combine(
                    datetime.date.today(),
                    datetime.time(12, 0)
                ):

                    if st.button(
                        "🔴 SALÍ DE MAÑANA",
                        use_container_width=True,
                        key="btn_mi_jornada_salida_manana"
                    ):

                        momento = datetime.datetime.now(
                            ZoneInfo("America/Argentina/Buenos_Aires")
                        ).replace(tzinfo=None)

                        horas = calcular_horas_jornada(
                            jornada[
                                "entrada_manana"
                            ],
                            momento
                        )

                        actualizar_jornada_empleado(
                            nombre_empleado,
                            "salida_manana",
                            momento
                        )

                        actualizar_jornada_empleado(
                            nombre_empleado,
                            "horas_manana",
                            horas
                        )

                        st.success(
                            f"✅ Salida registrada. "
                            f"Trabajaste {horas:.2f} horas."
                        )

                        st.rerun()

                else:

                    st.info(
                        "🕛 La mañana se cerró automáticamente "
                        "a las 12:00."
                    )

                    st.write(
                        f"⏱️ Horas mañana: "
                        f"**{float(jornada['horas_manana'] or 0):.2f} h**"
                    )

            else:

                st.info(
                    "🌅 Mañana: **0:00 h**"
                )

        st.markdown("---")

        # ==================================================
        # CIERRE AUTOMÁTICO DE LA TARDE A LAS 19:00
        # ==================================================

        if (
            jornada
            and jornada["entrada_tarde"]
            and not jornada["salida_tarde"]
        ):

            fecha_jornada = jornada["fecha"]

            cierre_tarde = datetime.datetime.combine(
                fecha_jornada,
                datetime.time(19, 0),
                tzinfo=ZoneInfo("America/Argentina/Buenos_Aires")
            ).replace(tzinfo=None)

            if ahora >= cierre_tarde:

                horas_tarde = calcular_horas_jornada(
                    jornada["entrada_tarde"],
                    cierre_tarde
                )

                actualizar_jornada_empleado(
                    nombre_empleado,
                    "salida_tarde",
                    cierre_tarde
                )

                actualizar_jornada_empleado(
                    nombre_empleado,
                    "horas_tarde",
                    horas_tarde
                )

                jornada = obtener_jornada_hoy(
                    nombre_empleado
                )

        # ==================================================
        # TARDE
        # ==================================================

        st.markdown("### ☀️ Jornada de la tarde")

        col_tarde_1, col_tarde_2 = st.columns(2)

        # --------------------------------------------------
        # ENTRADA TARDE
        # --------------------------------------------------

        with col_tarde_1:

            if jornada["entrada_tarde"]:

                st.success(
                    "🟢 Entrada de tarde registrada"
                )

                st.write(
                    "Hora de entrada:",
                    jornada[
                        "entrada_tarde"
                    ].strftime("%H:%M:%S")
                )

            elif (
                ahora >= datetime.datetime.combine(
                    datetime.date.today(),
                    datetime.time(14, 0)
                )
                and
                ahora < datetime.datetime.combine(
                    datetime.date.today(),
                    datetime.time(19, 0)
                )
            ):

                if st.button(
                    "🟢 ENTRÉ A LA TARDE",
                    use_container_width=True,
                    key="btn_mi_jornada_entrada_tarde"
                ):

                    momento = datetime.datetime.now(
                        ZoneInfo("America/Argentina/Buenos_Aires")
                    ).replace(tzinfo=None)

                    actualizar_jornada_empleado(
                        nombre_empleado,
                        "entrada_tarde",
                        momento
                    )

                    st.success(
                        "✅ Entrada de tarde registrada."
                    )

                    st.rerun()

            else:

                st.info(
                    "☀️ La jornada de tarde comienza "
                    "después de las 14:00."
                )

        # --------------------------------------------------
        # SALIDA TARDE
        # --------------------------------------------------

        with col_tarde_2:

            if jornada["salida_tarde"]:

                st.success(
                    "🔴 Jornada finalizada"
                )

                st.write(
                    "Hora de salida:",
                    jornada[
                        "salida_tarde"
                    ].strftime("%H:%M:%S")
                )

                st.write(
                    f"⏱️ Horas tarde: "
                    f"**{float(jornada['horas_tarde'] or 0):.2f} h**"
                )

            elif jornada["entrada_tarde"]:

                if st.button(
                    "🔴 FINALIZAR JORNADA",
                    use_container_width=True,
                    key="btn_mi_jornada_salida_tarde"
                ):

                    momento = datetime.datetime.now(
                        ZoneInfo("America/Argentina/Buenos_Aires")
                    ).replace(tzinfo=None)

                    horas = calcular_horas_jornada(
                        jornada[
                            "entrada_tarde"
                        ],
                        momento
                    )

                    actualizar_jornada_empleado(
                        nombre_empleado,
                        "salida_tarde",
                        momento
                    )

                    actualizar_jornada_empleado(
                        nombre_empleado,
                        "horas_tarde",
                        horas
                    )

                    st.success(
                        f"✅ Jornada finalizada. "
                        f"Trabajaste {horas:.2f} horas."
                    )

                    st.rerun()

            else:

                st.info(
                    "☀️ Tarde: **0:00 h**"
                )

        # ==================================================
        # TOTAL DEL DÍA
        # ==================================================

        jornada = obtener_jornada_hoy(
            nombre_empleado
        )

        horas_manana = float(
            jornada["horas_manana"] or 0
        )

        horas_tarde = float(
            jornada["horas_tarde"] or 0
        )

        horas_totales = (
            horas_manana
            + horas_tarde
        )

        actualizar_jornada_empleado(
            nombre_empleado,
            "horas_totales",
            horas_totales
        )

        st.markdown("---")

        st.metric(
            "⏱️ TOTAL TRABAJADO HOY",
            f"{horas_totales:.2f} horas"
        )

        st.info(
            "🔒 Los horarios se registran automáticamente "
            "con la hora del sistema. No se pueden modificar "
            "manualmente."
        )
# ==========================================================
# CONSOLA TRIPULACIÓN
# FUNCIONES DE ADMINISTRACIÓN DE JORNADAS
# ==========================================================

def obtener_jornadas_consola(
    fecha_desde,
    fecha_hasta,
    empleado=None
):

    conn = None
    cursor = None

    try:

        conn = get_conn()
        cursor = conn.cursor()

        if empleado:

            cursor.execute(
                """
                SELECT
                    id,
                    nombre_empleado,
                    fecha,
                    entrada_manana,
                    salida_manana,
                    entrada_tarde,
                    salida_tarde,
                    horas_manana,
                    horas_tarde,
                    horas_totales,
                    COALESCE(horas_extras, 0),
                    COALESCE(observacion_admin, ''),
                    estado
                FROM jornadas_empleados
                WHERE fecha >= %s
                  AND fecha <= %s
                  AND nombre_empleado = %s
                ORDER BY fecha DESC, nombre_empleado
                """,
                (
                    fecha_desde,
                    fecha_hasta,
                    empleado
                )
            )

        else:

            cursor.execute(
                """
                SELECT
                    id,
                    nombre_empleado,
                    fecha,
                    entrada_manana,
                    salida_manana,
                    entrada_tarde,
                    salida_tarde,
                    horas_manana,
                    horas_tarde,
                    horas_totales,
                    COALESCE(horas_extras, 0),
                    COALESCE(observacion_admin, ''),
                    estado
                FROM jornadas_empleados
                WHERE fecha >= %s
                  AND fecha <= %s
                ORDER BY fecha DESC, nombre_empleado
                """,
                (
                    fecha_desde,
                    fecha_hasta
                )
            )

        filas = cursor.fetchall()

        columnas = [
            "id",
            "nombre_empleado",
            "fecha",
            "entrada_manana",
            "salida_manana",
            "entrada_tarde",
            "salida_tarde",
            "horas_manana",
            "horas_tarde",
            "horas_totales",
            "horas_extras",
            "observacion_admin",
            "estado"
        ]

        return [
            dict(zip(columnas, fila))
            for fila in filas
        ]

    except Exception as e:

        st.error(
            f"❌ Error obteniendo jornadas: {e}"
        )

        return []

    finally:

        if cursor:
            cursor.close()

        if conn:
            conn.close()


def actualizar_jornada_consola(
    id_jornada,
    campo,
    valor_nuevo,
    modificado_por,
    motivo
):

    campos_permitidos = {
        "entrada_manana",
        "salida_manana",
        "entrada_tarde",
        "salida_tarde",
        "horas_manana",
        "horas_tarde",
        "horas_totales",
        "horas_extras",
        "observacion_admin"
    }

    if campo not in campos_permitidos:

        st.error(
            "❌ Campo no permitido."
        )

        return False

    conn = None
    cursor = None

    try:

        conn = get_conn()
        cursor = conn.cursor()

        cursor.execute(
            f"""
            SELECT
                nombre_empleado,
                {campo}
            FROM jornadas_empleados
            WHERE id = %s
            """,
            (
                id_jornada,
            )
        )

        resultado = cursor.fetchone()

        if not resultado:

            st.error(
                "❌ No se encontró la jornada."
            )

            return False

        empleado = resultado[0]
        valor_anterior = resultado[1]

        cursor.execute(
            f"""
            UPDATE jornadas_empleados
            SET {campo} = %s,
                actualizado_en = CURRENT_TIMESTAMP
            WHERE id = %s
            """,
            (
                valor_nuevo,
                id_jornada
            )
        )

        cursor.execute(
            """
            INSERT INTO historial_jornadas (
                id_jornada,
                empleado,
                campo_modificado,
                valor_anterior,
                valor_nuevo,
                motivo,
                modificado_por
            )
            VALUES (
                %s,
                %s,
                %s,
                %s,
                %s,
                %s,
                %s
            )
            """,
            (
                id_jornada,
                empleado,
                campo,
                str(valor_anterior)
                if valor_anterior is not None
                else "",
                str(valor_nuevo)
                if valor_nuevo is not None
                else "",
                motivo,
                modificado_por
            )
        )

        conn.commit()

        return True

    except Exception as e:

        if conn:
            conn.rollback()

        st.error(
            f"❌ Error modificando la jornada: {e}"
        )

        return False

    finally:

        if cursor:
            cursor.close()

        if conn:
            conn.close()


def obtener_historial_jornada(id_jornada):

    conn = None
    cursor = None

    try:

        conn = get_conn()
        cursor = conn.cursor()

        cursor.execute(
            """
            SELECT
                fecha_modificacion,
                modificado_por,
                campo_modificado,
                valor_anterior,
                valor_nuevo,
                motivo
            FROM historial_jornadas
            WHERE id_jornada = %s
            ORDER BY fecha_modificacion DESC
            """,
            (
                id_jornada,
            )
        )

        filas = cursor.fetchall()

        columnas = [
            "Fecha",
            "Modificado por",
            "Campo",
            "Antes",
            "Después",
            "Motivo"
        ]

        return [
            dict(zip(columnas, fila))
            for fila in filas
        ]

    except Exception as e:

        st.error(
            f"❌ Error obteniendo historial: {e}"
        )

        return []

    finally:

        if cursor:
            cursor.close()

        if conn:
            conn.close()  
# ==========================================================
# PANTALLA - CONSOLA TRIPULACIÓN
# ==========================================================

if menu == "🖥️ CONSOLA TRIPULACIÓN":

    st.header("🖥️ Consola Tripulación")

    st.markdown(
        "### Control y edición de jornadas de los operarios"
    )

    # ------------------------------------------------------
    # FILTROS
    # ------------------------------------------------------

    col1, col2, col3 = st.columns(3)

    with col1:

        fecha_desde_consola = st.date_input(
            "📅 Desde",
            value=datetime.date.today()
        )

    with col2:

        fecha_hasta_consola = st.date_input(
            "📅 Hasta",
            value=datetime.date.today()
        )

    # Obtener empleados
    jornadas_todas = obtener_jornadas_consola(
        fecha_desde_consola,
        fecha_hasta_consola
    )

    empleados_consola = sorted(
        list(
            set(
                jornada["nombre_empleado"]
                for jornada in jornadas_todas
            )
        )
    )

    with col3:

        empleado_consola = st.selectbox(
            "👤 Operario",
            ["Todos"] + empleados_consola
        )

    # ------------------------------------------------------
    # BUSCAR JORNADAS
    # ------------------------------------------------------

    if empleado_consola == "Todos":

        jornadas_consola = jornadas_todas

    else:

        jornadas_consola = obtener_jornadas_consola(
            fecha_desde_consola,
            fecha_hasta_consola,
            empleado_consola
        )

    st.markdown("---")

    # ------------------------------------------------------
    # RESUMEN
    # ------------------------------------------------------

    total_jornadas = len(jornadas_consola)

    total_horas = sum(
        float(jornada["horas_totales"] or 0)
        for jornada in jornadas_consola
    )

    total_extras = sum(
        float(jornada["horas_extras"] or 0)
        for jornada in jornadas_consola
    )

    c1, c2, c3 = st.columns(3)

    with c1:

        st.metric(
            "📋 Jornadas",
            total_jornadas
        )

    with c2:

        st.metric(
            "⏱️ Horas totales",
            f"{total_horas:.2f}"
        )

    with c3:

        st.metric(
            "➕ Horas extras",
            f"{total_extras:.2f}"
        )

    st.markdown("---")

    # ------------------------------------------------------
    # MOSTRAR JORNADAS
    # ------------------------------------------------------

    if not jornadas_consola:

        st.info(
            "ℹ️ No hay jornadas registradas para este período."
        )

    else:

        for jornada in jornadas_consola:

            fecha_jornada = jornada["fecha"]

            if hasattr(fecha_jornada, "strftime"):

                fecha_mostrar = fecha_jornada.strftime(
                    "%d/%m/%Y"
                )

            else:

                fecha_mostrar = str(fecha_jornada)

            with st.expander(
                f"👤 {jornada['nombre_empleado']} "
                f"— 📅 {fecha_mostrar} "
                f"— ⏱️ {float(jornada['horas_totales'] or 0):.2f} hs"
            ):

                # --------------------------------------------------
                # INFORMACIÓN ACTUAL
                # --------------------------------------------------

                st.markdown("### 🕐 Jornada registrada")

                col1, col2 = st.columns(2)

                with col1:

                    st.write(
                        "🌅 **Mañana**"
                    )

                    st.write(
                        f"Entrada: "
                        f"{jornada['entrada_manana'] or '-'}"
                    )

                    st.write(
                        f"Salida: "
                        f"{jornada['salida_manana'] or '-'}"
                    )

                    st.write(
                        f"Horas: "
                        f"{float(jornada['horas_manana'] or 0):.2f}"
                    )

                with col2:

                    st.write(
                        "🌇 **Tarde**"
                    )

                    st.write(
                        f"Entrada: "
                        f"{jornada['entrada_tarde'] or '-'}"
                    )

                    st.write(
                        f"Salida: "
                        f"{jornada['salida_tarde'] or '-'}"
                    )

                    st.write(
                        f"Horas: "
                        f"{float(jornada['horas_tarde'] or 0):.2f}"
                    )

                st.write(
                    f"⏱️ **Total: "
                    f"{float(jornada['horas_totales'] or 0):.2f} horas**"
                )

                st.write(
                    f"➕ **Horas extras: "
                    f"{float(jornada['horas_extras'] or 0):.2f}**"
                )

                # --------------------------------------------------
                # EDITAR
                # --------------------------------------------------

                st.markdown("---")

                st.markdown(
                    "### ✏️ Editar jornada"
                )

                entrada_manana_actual = jornada[
                    "entrada_manana"
                ]

                salida_manana_actual = jornada[
                    "salida_manana"
                ]

                entrada_tarde_actual = jornada[
                    "entrada_tarde"
                ]

                salida_tarde_actual = jornada[
                    "salida_tarde"
                ]

                # Convertir a hora para los time_input

                def convertir_hora(valor, defecto):

                    if valor is None:

                        return defecto

                    if isinstance(
                        valor,
                        datetime.datetime
                    ):

                        return valor.time()

                    if isinstance(
                        valor,
                        datetime.time
                    ):

                        return valor

                    return defecto

                entrada_manana_edit = st.time_input(
                    "Entrada mañana",
                    value=convertir_hora(
                        entrada_manana_actual,
                        datetime.time(8, 0)
                    ),
                    key=f"em_{jornada['id']}"
                )

                salida_manana_edit = st.time_input(
                    "Salida mañana",
                    value=convertir_hora(
                        salida_manana_actual,
                        datetime.time(12, 0)
                    ),
                    key=f"sm_{jornada['id']}"
                )

                entrada_tarde_edit = st.time_input(
                    "Entrada tarde",
                    value=convertir_hora(
                        entrada_tarde_actual,
                        datetime.time(14, 0)
                    ),
                    key=f"et_{jornada['id']}"
                )

                salida_tarde_edit = st.time_input(
                    "Salida tarde",
                    value=convertir_hora(
                        salida_tarde_actual,
                        datetime.time(19, 0)
                    ),
                    key=f"st_{jornada['id']}"
                )

                horas_extras_edit = st.number_input(
                    "➕ Horas extras",
                    min_value=0.0,
                    step=0.5,
                    value=float(
                        jornada["horas_extras"] or 0
                    ),
                    key=f"extras_{jornada['id']}"
                )

                observacion_edit = st.text_area(
                    "📝 Observación",
                    value=jornada[
                        "observacion_admin"
                    ] or "",
                    key=f"obs_{jornada['id']}"
                )

                motivo_edit = st.text_input(
                    "Motivo del cambio",
                    key=f"motivo_{jornada['id']}",
                    placeholder="Ej.: Corrección de horario informada por el encargado"
                )

                # --------------------------------------------------
                # CALCULAR NUEVAS HORAS
                # --------------------------------------------------

                fecha_base = jornada["fecha"]

                if isinstance(
                    fecha_base,
                    datetime.datetime
                ):

                    fecha_base = fecha_base.date()

                entrada_manana_dt = datetime.datetime.combine(
                    fecha_base,
                    entrada_manana_edit
                )

                salida_manana_dt = datetime.datetime.combine(
                    fecha_base,
                    salida_manana_edit
                )

                entrada_tarde_dt = datetime.datetime.combine(
                    fecha_base,
                    entrada_tarde_edit
                )

                salida_tarde_dt = datetime.datetime.combine(
                    fecha_base,
                    salida_tarde_edit
                )

                nuevas_horas_manana = calcular_horas_jornada(
                    entrada_manana_dt,
                    salida_manana_dt
                )

                nuevas_horas_tarde = calcular_horas_jornada(
                    entrada_tarde_dt,
                    salida_tarde_dt
                )

                nuevo_total = round(
                    nuevas_horas_manana
                    + nuevas_horas_tarde
                    + horas_extras_edit,
                    2
                )

                st.info(
                    f"⏱️ Nuevo total: "
                    f"**{nuevo_total:.2f} horas**"
                )

                # --------------------------------------------------
                # GUARDAR
                # --------------------------------------------------

                if st.button(
                    "💾 Guardar cambios",
                    key=f"guardar_consola_{jornada['id']}"
                ):

                    usuario_modifica = (
                        st.session_state.get(
                            "nombre_usuario",
                            st.session_state.get(
                                "usuario",
                                "Administrador"
                            )
                        )
                    )

                    motivo_final = (
                        motivo_edit.strip()
                        if motivo_edit.strip()
                        else "Corrección realizada desde Consola Tripulación"
                    )

                    actualizar_jornada_consola(
                        jornada["id"],
                        "entrada_manana",
                        datetime.datetime.combine(
                            fecha_base,
                            entrada_manana_edit
                        ),
                        usuario_modifica,
                        motivo_final
                    )

                    actualizar_jornada_consola(
                        jornada["id"],
                        "salida_manana",
                        datetime.datetime.combine(
                            fecha_base,
                            salida_manana_edit
                        ),
                        usuario_modifica,
                        motivo_final
                    )

                    actualizar_jornada_consola(
                        jornada["id"],
                        "entrada_tarde",
                        datetime.datetime.combine(
                            fecha_base,
                            entrada_tarde_edit
                        ),
                        usuario_modifica,
                        motivo_final
                    )

                    actualizar_jornada_consola(
                        jornada["id"],
                        "salida_tarde",
                        datetime.datetime.combine(
                            fecha_base,
                            salida_tarde_edit
                        ),
                        usuario_modifica,
                        motivo_final
                    )

                    actualizar_jornada_consola(
                        jornada["id"],
                        "horas_manana",
                        nuevas_horas_manana,
                        usuario_modifica,
                        motivo_final
                    )

                    actualizar_jornada_consola(
                        jornada["id"],
                        "horas_tarde",
                        nuevas_horas_tarde,
                        usuario_modifica,
                        motivo_final
                    )

                    actualizar_jornada_consola(
                        jornada["id"],
                        "horas_extras",
                        horas_extras_edit,
                        usuario_modifica,
                        motivo_final
                    )

                    actualizar_jornada_consola(
                        jornada["id"],
                        "horas_totales",
                        nuevo_total,
                        usuario_modifica,
                        motivo_final
                    )

                    actualizar_jornada_consola(
                        jornada["id"],
                        "observacion_admin",
                        observacion_edit,
                        usuario_modifica,
                        motivo_final
                    )

                    st.success(
                        "✅ Jornada actualizada correctamente."
                    )

                    st.rerun()

                # --------------------------------------------------
                # HISTORIAL
                # --------------------------------------------------

                historial = obtener_historial_jornada(
                    jornada["id"]
                )

                if historial:

                    st.markdown(
                        "### 📜 Historial de modificaciones"
                    )

                    st.dataframe(
                        pd.DataFrame(historial),
                        use_container_width=True,
                        hide_index=True
                    )                  

# ----------------------------------------------------
# PESTAÑA: ANALÍTICAS CENTRALES
# ----------------------------------------------------

if menu == "📈 ANALÍTICAS CENTRALES":

    st.header("Resumen General del Negocio")

    # Los ingresos de Analíticas se consultan directamente desde Neon.
    try:
        df_ingresos_analiticas = cargar_ingresos_desde_neon()
    except Exception as e:
        df_ingresos_analiticas = pd.DataFrame()
        st.error(f"No se pudieron cargar los ingresos desde Neon: {e}")

    total_gasto_facturas = (
        df_facturas["Monto (ARS)"].sum()
        if not df_facturas.empty else 0.0
    )

    total_pendiente_facturas = (
        df_facturas[
            df_facturas["Estado Pago"].str.contains(
                "Pendiente",
                case=False,
                na=False
            )
        ]["Monto (ARS)"].sum()
        if not df_facturas.empty else 0.0
    )

    total_tripulacion_global = (
        df_pagos_empleados["Monto (ARS)"].sum()
        if not df_pagos_empleados.empty else 0.0
    )

    if not df_ingresos_analiticas.empty:
        columna_monto_ingresos = (
            "Monto"
            if "Monto" in df_ingresos_analiticas.columns
            else "Monto Total (ARS)"
        )
        total_ingresos_global = (
            pd.to_numeric(
                df_ingresos_analiticas[columna_monto_ingresos],
                errors="coerce"
            ).fillna(0).sum()
            if columna_monto_ingresos in df_ingresos_analiticas.columns
            else 0.0
        )
    else:
        total_ingresos_global = 0.0

    total_has_global = (
        df_telemetria["Has Trabajadas"].sum()
        if not df_telemetria.empty else 0.0
    )

    total_litros_global = (
        df_telemetria["Gasoil Consumido (L)"].sum()
        if not df_telemetria.empty else 0.0
    )

    total_litros_cargados = (
        pd.to_numeric(df_combustible["Litros"], errors="coerce").fillna(0).sum()
        if not df_combustible.empty else 0.0
    )

    total_gasto_combustible = (
        pd.to_numeric(df_combustible["Total"], errors="coerce").fillna(0).sum()
        if not df_combustible.empty else 0.0
    )

    eficiencia_flota = (
        total_litros_global / total_has_global
        if total_has_global > 0 else 0.0
    )

    c1, c2, c3, c4 = st.columns(4)

    with c1:
        st.markdown(
            f"""
            <div class="card-box">
                <div class="card-title-custom">
                    💰 Facturación Total Ingresos
                </div>
                <div class="card-value-custom">
                    $ {total_ingresos_global:,.2f}
                </div>
            </div>
            """,
            unsafe_allow_html=True
        )

    with c2:
        st.markdown(
            f"""
            <div class="card-box">
                <div class="card-title-custom">
                    🧾 Gastos Comerciales
                </div>
                <div class="card-value-custom">
                    $ {total_gasto_facturas:,.2f}
                </div>
            </div>
            """,
            unsafe_allow_html=True
        )

    with c3:
        st.markdown(
            f"""
            <div class="card-box">
                <div class="card-title-custom">
                    👥 Total Costo Tripulación
                </div>
                <div class="card-value-custom">
                    $ {total_tripulacion_global:,.2f}
                </div>
            </div>
            """,
            unsafe_allow_html=True
        )

    with c4:
        st.markdown(
            f"""
            <div class="card-box">
                <div class="card-title-custom">
                    🔴 Cuentas Proveedores Pendientes
                </div>
                <div class="card-value-custom">
                    $ {total_pendiente_facturas:,.2f}
                </div>
            </div>
            """,
            unsafe_allow_html=True
        )

    st.markdown("<br>", unsafe_allow_html=True)

    c5, c6, c7, c8 = st.columns(4)

    with c5:
        st.markdown(
            f"""
            <div class="card-box">
                <div class="card-title-custom">🌾 Superficie Total Operada</div>
                <div class="card-value-custom">{total_has_global:,.1f} Has</div>
            </div>
            """,
            unsafe_allow_html=True
        )

    with c6:
        st.markdown(
            f"""
            <div class="card-box">
                <div class="card-title-custom">⚙️ Consumo Estimado por Labor</div>
                <div class="card-value-custom">{eficiencia_flota:.2f} L/Ha</div>
            </div>
            """,
            unsafe_allow_html=True
        )

    with c7:
        st.markdown(
            f"""
            <div class="card-box">
                <div class="card-title-custom">⛽ Litros Cargados</div>
                <div class="card-value-custom">{total_litros_cargados:,.0f} L</div>
            </div>
            """,
            unsafe_allow_html=True
        )

    with c8:
        st.markdown(
            f"""
            <div class="card-box">
                <div class="card-title-custom">💳 Gasto en Combustible</div>
                <div class="card-value-custom">$ {total_gasto_combustible:,.2f}</div>
            </div>
            """,
            unsafe_allow_html=True
        )


    # ======================================================
    # EVOLUCIÓN MENSUAL: INGRESOS, GASTOS Y RESULTADO
    # ======================================================

    st.divider()
    st.subheader("📈 Evolución mensual del negocio")
    st.caption(
        "Comparación de ingresos y gastos comerciales registrados en Neon. "
        "El resultado mensual es ingresos menos gastos comerciales."
    )

    df_ing_graf = df_ingresos_analiticas.copy()
    df_gas_graf = df_facturas.copy()

    if not df_ing_graf.empty and "Fecha" in df_ing_graf.columns:
        df_ing_graf["_fecha_grafica"] = pd.to_datetime(
            df_ing_graf["Fecha"], errors="coerce"
        )
        df_ing_graf["_monto_grafica"] = pd.to_numeric(
            df_ing_graf["Monto"], errors="coerce"
        ).fillna(0)
    else:
        df_ing_graf = pd.DataFrame(
            columns=["_fecha_grafica", "_monto_grafica"]
        )

    if not df_gas_graf.empty and "Fecha Registro" in df_gas_graf.columns:
        df_gas_graf["_fecha_grafica"] = pd.to_datetime(
            df_gas_graf["Fecha Registro"], errors="coerce"
        )
        df_gas_graf["_monto_grafica"] = pd.to_numeric(
            df_gas_graf["Monto (ARS)"], errors="coerce"
        ).fillna(0)
    else:
        df_gas_graf = pd.DataFrame(
            columns=["_fecha_grafica", "_monto_grafica"]
        )

    fechas_validas = []

    if not df_ing_graf.empty:
        fechas_validas.extend(
            df_ing_graf["_fecha_grafica"].dropna().dt.year.tolist()
        )

    if not df_gas_graf.empty:
        fechas_validas.extend(
            df_gas_graf["_fecha_grafica"].dropna().dt.year.tolist()
        )

    if fechas_validas:
        anios_disponibles = sorted(set(fechas_validas), reverse=True)

        anio_seleccionado = st.selectbox(
            "Seleccionar ejercicio",
            options=anios_disponibles,
            index=0,
            key="analiticas_anio_mensual"
        )

        nombres_meses = [
            "Enero", "Febrero", "Marzo", "Abril",
            "Mayo", "Junio", "Julio", "Agosto",
            "Septiembre", "Octubre", "Noviembre", "Diciembre"
        ]

        ingresos_mes = [0.0] * 12
        gastos_mes = [0.0] * 12

        if not df_ing_graf.empty:
            ingresos_filtrados = df_ing_graf[
                df_ing_graf["_fecha_grafica"].dt.year == anio_seleccionado
            ]

            sumas_ingresos = ingresos_filtrados.groupby(
                ingresos_filtrados["_fecha_grafica"].dt.month
            )["_monto_grafica"].sum()

            for mes, monto in sumas_ingresos.items():
                ingresos_mes[int(mes) - 1] = float(monto)

        if not df_gas_graf.empty:
            gastos_filtrados = df_gas_graf[
                df_gas_graf["_fecha_grafica"].dt.year == anio_seleccionado
            ]

            sumas_gastos = gastos_filtrados.groupby(
                gastos_filtrados["_fecha_grafica"].dt.month
            )["_monto_grafica"].sum()

            for mes, monto in sumas_gastos.items():
                gastos_mes[int(mes) - 1] = float(monto)

        df_evolucion = pd.DataFrame(
            {
                "Ingresos": ingresos_mes,
                "Gastos comerciales": gastos_mes,
            },
            index=nombres_meses
        )

        df_evolucion["Resultado"] = (
            df_evolucion["Ingresos"] -
            df_evolucion["Gastos comerciales"]
        )

        total_ingresos_anio = float(df_evolucion["Ingresos"].sum())
        total_gastos_anio = float(df_evolucion["Gastos comerciales"].sum())
        resultado_anio = total_ingresos_anio - total_gastos_anio

        m1, m2, m3 = st.columns(3)
        m1.metric("Ingresos del año", f"$ {total_ingresos_anio:,.2f}")
        m2.metric("Gastos comerciales del año", f"$ {total_gastos_anio:,.2f}")
        m3.metric("Resultado del año", f"$ {resultado_anio:,.2f}")

        st.markdown("#### Ingresos y gastos por mes")
        st.bar_chart(
            df_evolucion[["Ingresos", "Gastos comerciales"]],
            use_container_width=True
        )

        st.markdown("#### Resultado mensual")
        st.line_chart(
            df_evolucion[["Resultado"]],
            use_container_width=True
        )

        with st.expander("Ver detalle mensual en tabla"):
            df_tabla_evolucion = df_evolucion.copy()
            df_tabla_evolucion.index.name = "Mes"
            st.dataframe(
                df_tabla_evolucion.style.format("$ {:,.2f}"),
                use_container_width=True
            )

    else:
        st.info(
            "Todavía no hay ingresos o gastos con fechas válidas en Neon "
            "para construir la evolución mensual."
        )

# ----------------------------------------------------
# PESTAÑA: LABORES Y LOTES
# ----------------------------------------------------

if menu == "🚜 LABORES Y LOTES":

    st.header("🚜 Partes Diarios de Labores")

    with st.form("form_labores"):

        col_la1, col_la2, col_la3 = st.columns(3)

        with col_la1:

            fecha_labor = st.date_input(
                "Fecha de Labor",
                value=datetime.date.today()
            )

            lote_labor = st.text_input(
                "Nombre del Campo / Lote"
            )

        with col_la2:

            maquina_labor = st.selectbox(
                "Maquinaria Activa",
                [
                    "Cosechadora CR 7.90",
                    "Tractor Valtra",
                    "Pulverizadora",
                    "Camión"
                ]
            )

            has_labor = st.number_input(
                "Hectáreas Trabajadas",
                min_value=0.0,
                step=1.0
            )

        with col_la3:

            eficiencia_labor = st.number_input(
                "Consumo Gasoil (Litros por Ha)",
                min_value=0.0,
                step=0.1
            )

            btn_lab = st.form_submit_button(
                "💾 Guardar Trabajo"
            )


    if btn_lab:

        if not lote_labor.strip():
            st.warning("Ingresá el nombre del campo o lote.")
        elif has_labor <= 0:
            st.warning("Las hectáreas trabajadas deben ser mayores a cero.")
        elif guardar_labor_neon(
            fecha_labor,
            maquina_labor,
            lote_labor.strip(),
            has_labor,
            eficiencia_labor,
        ):
            st.success("✅ Trabajo guardado permanentemente en Neon.")
            st.rerun()

    st.divider()


    st.subheader(
        "📋 Partes diarios registrados"
    )


    if not df_telemetria.empty:

        st.dataframe(
            df_telemetria.drop(columns=["ID"], errors="ignore"),
            use_container_width=True,
            hide_index=True
        )


        st.divider()


        st.subheader(
            "✏️ Editar o eliminar parte diario"
        )


        labor = st.selectbox(

            "Seleccionar trabajo",

            df_telemetria.index,

            format_func=lambda x:
                f"{df_telemetria.loc[x,'Fecha']} - {df_telemetria.loc[x,'Lote']}"

        )


        fila = df_telemetria.loc[labor]


        fecha_edit = st.date_input(

            "Fecha",

            value=pd.to_datetime(
                fila["Fecha"]
            )

        )


        maquinas = [

            "Cosechadora CR 7.90",

            "Tractor Valtra",

            "Pulverizadora",

            "Camión"

        ]


        maquina_edit = st.selectbox(

            "Maquinaria",

            maquinas,

            index=maquinas.index(
                fila["Maquinaria"]
            )
            if fila["Maquinaria"] in maquinas
            else 0

        )


        lote_edit = st.text_input(

            "Lote",

            value=fila["Lote"]

        )


        has_edit = st.number_input(

            "Hectáreas",

            value=float(
                fila["Has Trabajadas"]
            )

        )


        eficiencia_edit = st.number_input(

            "Litros por Ha",

            value=float(
                fila["Eficiencia (L/Ha)"]
            )

        )


        col1, col2 = st.columns(2)


        with col1:


            if st.button(
                "💾 Guardar cambios",
                key="guardar_parte_diario"
            ):

                if actualizar_labor_neon(
                    fila["ID"],
                    fecha_edit,
                    maquina_edit,
                    lote_edit.strip(),
                    has_edit,
                    eficiencia_edit,
                ):
                    st.success("✅ Parte diario actualizado en Neon.")
                    st.rerun()



        with col2:


            if st.button(
                "🗑 Eliminar parte diario",
                key="eliminar_parte_diario"
            ):

                if eliminar_labor_neon(fila["ID"]):
                    st.success("✅ Parte diario eliminado de Neon.")
                    st.rerun()



    else:

        st.info(
            "Todavía no hay partes diarios cargados"
        )

# ----------------------------------------------------
# PESTAÑA: GASTOS COMERCIALES
# ----------------------------------------------------
if menu == "🧾 GASTOS COMERCIALES":

    st.header("🧾 Gastos Comerciales")

    with st.form("form_gastos"):

        c1, c2 = st.columns(2)

        with c1:

            fecha = st.date_input(
                "Fecha",
                value=datetime.date.today()
            )

            proveedor = st.text_input("Proveedor")

            categoria = st.selectbox(
                "Categoría",
                [
                    "Combustible",
                    "Repuestos",
                    "Insumos",
                    "Servicios",
                    "Impuestos",
                    "Otros"
                ]
            )

        with c2:

            monto = st.number_input(
                "Monto ($)",
                min_value=0.0,
                step=1000.0
            )

            estado = st.selectbox(
                "Estado",
                ["Pendiente de Pago", "Pagado"]
            )

            lote = st.text_input("Lote / Destino")

            archivo_adjunto = st.file_uploader(
                "📎 Subir comprobante",
                type=["pdf", "png", "jpg", "jpeg"]
            )

        guardar = st.form_submit_button("💾 Guardar gasto")

    if guardar:

        ahora = datetime.datetime.now()

        nombre_archivo_guardado = ""
        comprobante_data = None

        if archivo_adjunto is not None:

            nombre_archivo_guardado = (
                f"{int(ahora.timestamp())}_"
                f"{archivo_adjunto.name}"
            )

            comprobante_data = archivo_adjunto.getvalue()

        nuevo = {
            "ID": str(int(ahora.timestamp() * 1000000)),
            "Fecha Registro": fecha.strftime("%Y-%m-%d"),
            "Proveedor": proveedor,
            "Monto Original": monto,
            "Moneda": "ARS",
            "Monto (ARS)": monto,
            "Categoría": categoria,
            "Lote Asignado": lote,
            "Estado Pago": estado,
            "Archivo Comprobante": nombre_archivo_guardado
        }

        guardado = guardar_gasto_en_neon(
            nuevo,
            comprobante_data
        )

        if guardado:

            st.success(
                "✅ Gasto y comprobante guardados en Neon."
            )

            st.rerun()

    st.divider()

    st.subheader("📋 Gastos registrados")

    # Recargar los datos desde Neon para no depender del CSV local.
    df_facturas = cargar_gastos_desde_neon()

    for columna, valor in columnas_facturas.items():

        if columna not in df_facturas.columns:
            df_facturas[columna] = valor

    if not df_facturas.empty:

        st.dataframe(
            df_facturas,
            use_container_width=True
        )

        total = pd.to_numeric(
            df_facturas["Monto (ARS)"],
            errors="coerce"
        ).fillna(0).sum()

        pendientes = pd.to_numeric(
            df_facturas.loc[
                df_facturas["Estado Pago"] == "Pendiente de Pago",
                "Monto (ARS)"
            ],
            errors="coerce"
        ).fillna(0).sum()

        c1, c2 = st.columns(2)

        with c1:
            st.metric(
                "💰 Total Gastos",
                f"$ {total:,.2f}"
            )

        with c2:
            st.metric(
                "🔴 Pendiente de Pago",
                f"$ {pendientes:,.2f}"
            )

        st.divider()

        st.subheader("📎 Comprobantes guardados")

        conn_comprobantes = None
        cursor_comprobantes = None

        try:

            conn_comprobantes = get_conn()
            cursor_comprobantes = conn_comprobantes.cursor()

            cursor_comprobantes.execute(
                """
                SELECT
                    id_gasto,
                    archivo_comprobante,
                    comprobante_data
                FROM gastos_comerciales
                ORDER BY fecha_registro DESC
                """
            )

            comprobantes = cursor_comprobantes.fetchall()

            for id_gasto, nombre_archivo, contenido in comprobantes:

                if not contenido:
                    continue

                nombre_mostrar = (
                    nombre_archivo
                    or f"comprobante_{id_gasto}"
                )

                with st.expander(
                    f"📄 Gasto {id_gasto} — {nombre_mostrar}"
                ):

                    st.download_button(
                        label="⬇️ Descargar comprobante",
                        data=bytes(contenido),
                        file_name=nombre_mostrar,
                        mime=(
                            "application/pdf"
                            if nombre_mostrar.lower().endswith(".pdf")
                            else (
                                "image/png"
                                if nombre_mostrar.lower().endswith(".png")
                                else (
                                    "image/jpeg"
                                    if nombre_mostrar.lower().endswith(
                                        (".jpg", ".jpeg")
                                    )
                                    else "application/octet-stream"
                                )
                            )
                        ),
                        key=f"descargar_gasto_{id_gasto}"
                    )

                    if nombre_mostrar.lower().endswith(
                        (".png", ".jpg", ".jpeg")
                    ):

                        st.image(bytes(contenido))

        except Exception as e:

            st.error(
                f"❌ No se pudieron recuperar los comprobantes: {e}"
            )

        finally:

            if cursor_comprobantes:
                cursor_comprobantes.close()

            if conn_comprobantes:
                conn_comprobantes.close()

    else:

        st.info("Todavía no hay gastos cargados en Neon.")  
# ----------------------------------------------------
# PESTAÑA: CUENTAS PENDIENTES
# ----------------------------------------------------

if menu == "🔍 CUENTAS PENDIENTES":

    st.header("🔍 Cuentas Pendientes de Proveedores")

    df_solo_pendientes = df_facturas[
        df_facturas["Estado Pago"] == "Pendiente de Pago"
    ]

    if not df_solo_pendientes.empty:

        for idx, fila in df_solo_pendientes.iterrows():

            with st.expander(
                f"❌ {fila['Proveedor']} — "
                f"$ {fila['Monto Original']:,.2f}"
            ):

                with st.form(
                    key=f"form_liquidar_{fila['ID']}_{idx}"
                ):

                    archivo_pendiente = st.file_uploader(
                        "Adjuntar Comprobante:",
                        type=[
                            "pdf",
                            "png",
                            "jpg",
                            "jpeg"
                        ],
                        key=f"file_pend_{fila['ID']}_{idx}"
                    )

                    btn_cerrar_caso = st.form_submit_button(
                        "🟢 Marcar como PAGADO"
                    )

                    if btn_cerrar_caso:

                        if archivo_pendiente is None:

                            st.warning(
                                "⚠️ Adjuntá el comprobante antes de marcar el gasto como pagado."
                            )

                        else:

                            nombre_archivo_guardado = (
                                f"liquidado_"
                                f"{int(datetime.datetime.now().timestamp())}_"
                                f"{archivo_pendiente.name}"
                            )

                            ruta_comprobante = os.path.join(
                                "comprobantes",
                                nombre_archivo_guardado
                            )

                            with open(
                                ruta_comprobante,
                                "wb"
                            ) as f:

                                f.write(
                                    archivo_pendiente.getbuffer()
                                )

                            # ==========================================
                            # ACTUALIZAR GASTO EN NEON
                            # ==========================================

                            conn = None
                            cursor = None

                            try:

                                conn = get_conn()
                                cursor = conn.cursor()

                                cursor.execute(
                                    """
                                    UPDATE gastos_comerciales
                                    SET
                                        estado_pago = %s,
                                        archivo_comprobante = %s
                                    WHERE id_gasto = %s
                                    """,
                                    (
                                        "Pagado",
                                        nombre_archivo_guardado,
                                        str(fila["ID"])
                                    )
                                )

                                conn.commit()

                            except Exception as e:

                                if conn:
                                    conn.rollback()

                                st.error(
                                    f"❌ No se pudo actualizar el gasto en Neon: {e}"
                                )

                                st.stop()

                            finally:

                                if cursor:
                                    cursor.close()

                                if conn:
                                    conn.close()

                            # ==========================================
                            # ACTUALIZAR TABLA EN MEMORIA
                            # ==========================================

                            df_facturas.loc[
                                df_facturas["ID"].astype(str)
                                == str(fila["ID"]),
                                "Estado Pago"
                            ] = "Pagado"

                            df_facturas.loc[
                                df_facturas["ID"].astype(str)
                                == str(fila["ID"]),
                                "Archivo Comprobante"
                            ] = nombre_archivo_guardado

                            # ==========================================
                            # ACTUALIZAR CSV DE RESPALDO
                            # ==========================================

                            df_facturas.to_csv(
                                "datos_facturas.csv",
                                index=False
                            )

                            st.success(
                                "✅ ¡Gasto marcado como PAGADO y actualizado en Neon!"
                            )

                            st.rerun()

    else:

        st.success(
            "👌 ¡Ningún gasto pendiente!"
        )
# ============================================================
# FUNCIONES PARA LIQUIDACIONES
# ============================================================

import io


def guardar_comprobantes(archivos, nuevo_id):

    nombres = []

    if not archivos:
        return nombres

    carpeta = "comprobantes_pagos"

    os.makedirs(
        carpeta,
        exist_ok=True
    )

    for archivo in archivos:

        if archivo is None:
            continue

        extension = os.path.splitext(
            archivo.name
        )[1]

        nombre_archivo = (
            f"liquidacion_{nuevo_id}_"
            f"{len(nombres) + 1}"
            f"{extension}"
        )

        ruta = os.path.join(
            carpeta,
            nombre_archivo
        )

        with open(
            ruta,
            "wb"
        ) as f:

            f.write(
                archivo.getbuffer()
            )

        nombres.append(
            nombre_archivo
        )

    return nombres


def generar_pdf_liquidacion(
    nuevo_id,
    empleado,
    fecha,
    horas,
    valor_hora,
    monto_trabajado,
    bonificacion,
    descuento,
    monto_final,
    adelanto_anterior,
    pendiente_anterior,
    compensado,
    neto_pagar,
    monto_pagado,
    adelanto_final,
    pendiente_final,
    concepto
):

    buffer = io.BytesIO()

    documento = SimpleDocTemplate(
        buffer,
        pagesize=A4,
        rightMargin=15 * mm,
        leftMargin=15 * mm,
        topMargin=15 * mm,
        bottomMargin=15 * mm
    )

    estilos = getSampleStyleSheet()

    elementos = []

    elementos.append(
        Paragraph(
            "<b>D&A CANDELERO AGRO</b>",
            estilos["Title"]
        )
    )

    elementos.append(
        Spacer(
            1,
            8
        )
    )

    elementos.append(
        Paragraph(
            "<b>LIQUIDACIÓN DE PERSONAL</b>",
            estilos["Heading2"]
        )
    )

    elementos.append(
        Spacer(
            1,
            10
        )
    )

    datos = [
        ["Empleado", str(empleado)],
        ["Fecha", str(fecha)],
        ["ID Liquidación", str(nuevo_id)],
        ["Concepto", str(concepto)],
        ["Horas trabajadas", f"{horas:,.2f}"],
        ["Valor hora", f"$ {valor_hora:,.2f}"],
        ["Monto trabajado", f"$ {monto_trabajado:,.2f}"],
        ["Bonificación", f"$ {bonificacion:,.2f}"],
        ["Descuento", f"$ {descuento:,.2f}"],
        ["Total final trabajo", f"$ {monto_final:,.2f}"],
        ["Adelanto anterior", f"$ {adelanto_anterior:,.2f}"],
        ["Pendiente anterior", f"$ {pendiente_anterior:,.2f}"],
        ["Adelanto compensado", f"$ {compensado:,.2f}"],
        ["Neto a pagar", f"$ {neto_pagar:,.2f}"],
        ["Monto realmente pagado", f"$ {monto_pagado:,.2f}"],
        ["Adelanto final", f"$ {adelanto_final:,.2f}"],
        ["Pendiente final", f"$ {pendiente_final:,.2f}"],
    ]

    tabla = Table(
        datos,
        colWidths=[
            75 * mm,
            95 * mm
        ]
    )

    tabla.setStyle(
        TableStyle([
            (
                "GRID",
                (0, 0),
                (-1, -1),
                0.5,
                colors.grey
            ),
            (
                "BACKGROUND",
                (0, 0),
                (0, -1),
                colors.lightgrey
            ),
            (
                "FONTNAME",
                (0, 0),
                (0, -1),
                "Helvetica-Bold"
            ),
            (
                "FONTNAME",
                (1, 0),
                (1, -1),
                "Helvetica"
            ),
            (
                "VALIGN",
                (0, 0),
                (-1, -1),
                "MIDDLE"
            ),
            (
                "PADDING",
                (0, 0),
                (-1, -1),
                6
            ),
        ])
    )

    elementos.append(
        tabla
    )

    elementos.append(
        Spacer(
            1,
            20
        )
    )

    elementos.append(
        Paragraph(
            "Firma del empleado: ______________________________",
            estilos["Normal"]
        )
    )

    elementos.append(
        Spacer(
            1,
            15
        )
    )

    elementos.append(
        Paragraph(
            "Firma responsable: ________________________________",
            estilos["Normal"]
        )
    )

    documento.build(
        elementos
    )

    buffer.seek(0)

    return buffer.getvalue()


def obtener_saldos_empleado(
    df_pagos,
    empleado
):

    if df_pagos.empty:

        return {
            "adelanto": 0.0,
            "pendiente": 0.0
        }

    df_emp = df_pagos[
        df_pagos["Nombre Empleado"].astype(str).str.strip()
        == str(empleado).strip()
    ].copy()

    if df_emp.empty:

        return {
            "adelanto": 0.0,
            "pendiente": 0.0
        }

    # ==========================================
    # ORDENAR LOS MOVIMIENTOS
    # ==========================================

    if "Fecha Pago" in df_emp.columns:

        df_emp["_orden_fecha"] = pd.to_datetime(
            df_emp["Fecha Pago"],
            errors="coerce"
        )

    else:

        df_emp["_orden_fecha"] = pd.NaT

    df_emp["_orden_id"] = pd.to_numeric(
        df_emp["ID_Pago"],
        errors="coerce"
    ).fillna(0)

    df_emp = df_emp.sort_values(
        by=[
            "_orden_fecha",
            "_orden_id"
        ]
    )

    # ==========================================
    # TOMAR EL ÚLTIMO SALDO REAL
    # ==========================================

    ultima_fila = df_emp.iloc[-1]

    saldo_adelanto = pd.to_numeric(
        ultima_fila.get(
            "Saldo Adelanto (ARS)",
            0
        ),
        errors="coerce"
    )

    saldo_pendiente = pd.to_numeric(
        ultima_fila.get(
            "Saldo Pendiente Pago (ARS)",
            0
        ),
        errors="coerce"
    )

    if pd.isna(
        saldo_adelanto
    ):

        saldo_adelanto = 0.0

    if pd.isna(
        saldo_pendiente
    ):

        saldo_pendiente = 0.0

    return {
        "adelanto": float(
            max(
                saldo_adelanto,
                0.0
            )
        ),
        "pendiente": float(
            max(
                saldo_pendiente,
                0.0
            )
        )
    }


def obtener_saldo_adelanto(
    df_pagos,
    empleado
):

    saldos = obtener_saldos_empleado(
        df_pagos,
        empleado
    )

    return saldos["adelanto"]
# ----------------------------------------------------
# PESTAÑA: SISTEMA DE TRIPULACIÓN
# ----------------------------------------------------

if menu == "👥 SISTEMA DE TRIPULACIÓN":

    st.header("👤 Personal y Comisiones de la Tripulación")

    emp_col1, emp_col2 = st.columns(2)

    # ==================================================
    # COLUMNA 1 - PERSONAL
    # ==================================================

    with emp_col1:

        st.subheader("1. Gestión del Personal Fijo")

        if not df_empleados.empty:

            st.dataframe(
                df_empleados,
                use_container_width=True
            )

        st.markdown("---")

        st.subheader(
            "Agregar Nuevo Integrante "
            "(si ingresa alguien nuevo)"
        )

        with st.form("form_alta_empleado"):

            n_nombre = st.text_input(
                "Nombre Completo (Ej: Juan Perez)"
            )

            n_puesto = st.selectbox(
                "Rol",
                [
                    "Maquinista Cosechadora",
                    "Tractorista",
                    "Ayudante / Mecánico"
                ]
            )

            n_porcentaje = st.number_input(
                "Comisión (%)",
                min_value=0.0,
                max_value=100.0,
                step=0.1,
                value=0.0
            )

            btn_alta_emp = st.form_submit_button(
                "💾 Guardar Nuevo Operario"
            )

            if btn_alta_emp and n_nombre:

                nuevo_emp = {
                    "Nombre": n_nombre.strip(),
                    "Puesto": n_puesto,
                    "Porcentaje (%)": n_porcentaje
                }

                conn_nuevo_emp = None
                cursor_nuevo_emp = None

                try:

                    conn_nuevo_emp = get_conn()
                    cursor_nuevo_emp = conn_nuevo_emp.cursor()

                    cursor_nuevo_emp.execute(
                        """
                        INSERT INTO empleados (
                            nombre,
                            puesto,
                            porcentaje
                        )
                        VALUES (
                            %s,
                            %s,
                            %s
                        )
                        """,
                        (
                            nuevo_emp["Nombre"],
                            nuevo_emp["Puesto"],
                            float(
                                nuevo_emp["Porcentaje (%)"]
                                or 0
                            )
                        )
                    )

                    conn_nuevo_emp.commit()

                    df_empleados = pd.concat(
                        [
                            df_empleados,
                            pd.DataFrame([nuevo_emp])
                        ],
                        ignore_index=True
                    )

                    df_empleados.to_csv(
                        "registro_empleados.csv",
                        index=False,
                        encoding="utf-8-sig"
                    )

                    st.success(
                        "✔ Operario agregado correctamente."
                    )

                    st.rerun()

                except Exception as e:

                    if conn_nuevo_emp:
                        conn_nuevo_emp.rollback()

                    st.error(
                        f"❌ No se pudo guardar el operario en Neon: {e}"
                    )

                finally:

                    if cursor_nuevo_emp:
                        cursor_nuevo_emp.close()

                    if conn_nuevo_emp:
                        conn_nuevo_emp.close()
    # ==================================================
    # COLUMNA 2 - MOVIMIENTOS DE CUENTA
    # ==================================================

    with emp_col2:

        st.subheader(
            "2. Cargar Movimiento de Cuenta"
        )

        tipo_carga = st.radio(
           "Tipo de carga:",
        [
            "🕐 Jornada por día",
            "📋 Liquidación por horas totales",
            "🌾 Pago por hectárea"
        ],
        horizontal=True
        )

        # ==================================================
        # JORNADA POR DÍA
        # ==================================================

        if tipo_carga == "🕐 Jornada por día":

            with st.form(
                "form_pago_empleado_diario"
            ):

                if not df_empleados.empty:

                    emp_seleccionado = st.selectbox(
                        "Seleccionar Operario",
                        df_empleados["Nombre"].tolist()
                    )

                    tipo_registro = st.radio(
                        "Tipo:",
                        [
                            "Liquidación / Pago",
                            "Reintegro / Devolución"
                        ]
                    )

                    st.markdown(
                        "### 🕐 Jornada trabajada"
                    )

                    p_fecha_trabajo = st.date_input(
                        "📅 Día trabajado",
                        value=datetime.datetime.today()
                    )

                    col_hora1, col_hora2 = st.columns(2)

                    with col_hora1:

                        p_hora_entrada = st.time_input(
                            "🟢 Hora de entrada"
                        )

                    with col_hora2:

                        p_hora_salida = st.time_input(
                            "🔴 Hora de salida"
                        )

                    p_valor_hora = st.number_input(
                        "💰 Valor por hora ($ ARS)",
                        min_value=0.0,
                        step=100.0,
                        value=0.0
                    )

                    entrada_minutos = (
                        p_hora_entrada.hour * 60
                        + p_hora_entrada.minute
                    )

                    salida_minutos = (
                        p_hora_salida.hour * 60
                        + p_hora_salida.minute
                    )

                    if salida_minutos >= entrada_minutos:

                        minutos_trabajados = (
                            salida_minutos
                            - entrada_minutos
                        )

                    else:

                        minutos_trabajados = (
                            (24 * 60 - entrada_minutos)
                            + salida_minutos
                        )

                    horas_trabajadas = (
                        minutos_trabajados / 60
                    )

                    monto_calculado = (
                        horas_trabajadas
                        * p_valor_hora
                    )

                    st.info(
                        f"⏱️ Horas trabajadas: "
                        f"**{horas_trabajadas:.2f} h**\n\n"
                        f"💰 Total calculado: "
                        f"**$ {monto_calculado:,.2f}**"
                    )

                    p_estado = st.radio(
                        "Estado:",
                        [
                            "Pagado",
                            "Pendiente"
                        ],
                        horizontal=True
                    )

                    p_concepto = st.text_input(
                        "Detalle",
                        value="Jornada trabajada"
                    )

                    p_comprobante = st.file_uploader(
                        "📎 Comprobante de pago (opcional)",
                        type=[
                            "pdf",
                            "png",
                            "jpg",
                            "jpeg",
                            "webp"
                        ]
                    )

                    btn_pago_emp = st.form_submit_button(
                        "💳 Guardar Movimiento"
                    )

                    if btn_pago_emp:

                        if p_valor_hora <= 0:

                            st.error(
                                "❌ Tenés que ingresar "
                                "un valor por hora."
                            )

                        elif minutos_trabajados <= 0:

                            st.error(
                                "❌ La hora de salida debe "
                                "ser posterior a la entrada."
                            )

                        else:

                            nuevo_id = str(
                                int(
                                    datetime.datetime.now().timestamp()
                                    * 1000
                                )
                            )

                            nombre_comprobante = ""

                            if p_comprobante is not None:

                                carpeta = (
                                    "comprobantes_pagos"
                                )

                                os.makedirs(
                                    carpeta,
                                    exist_ok=True
                                )

                                extension = os.path.splitext(
                                    p_comprobante.name
                                )[1]

                                nombre_comprobante = (
                                    f"{nuevo_id}{extension}"
                                )

                                ruta_comprobante = os.path.join(
                                    carpeta,
                                    nombre_comprobante
                                )

                                with open(
                                    ruta_comprobante,
                                    "wb"
                                ) as archivo:

                                    archivo.write(
                                        p_comprobante.getbuffer()
                                    )

                            nuevo_pago = {

                                "ID_Pago": nuevo_id,

                                "Fecha Pago":
                                    datetime.datetime.now().strftime(
                                        "%Y-%m-%d"
                                    ),

                                "Nombre Empleado":
                                    emp_seleccionado,

                                "Fecha Trabajo":
                                    p_fecha_trabajo.strftime(
                                        "%Y-%m-%d"
                                    ),

                                "Hora Entrada":
                                    p_hora_entrada.strftime(
                                        "%H:%M"
                                    ),

                                "Hora Salida":
                                    p_hora_salida.strftime(
                                        "%H:%M"
                                    ),

                                "Horas Trabajadas":
                                    round(
                                        horas_trabajadas,
                                        2
                                    ),

                                "Valor Hora":
                                    round(
                                        p_valor_hora,
                                        2
                                    ),

                                "Monto (ARS)":
                                    round(
                                        monto_calculado,
                                        2
                                    ),

                                "Tipo Registro":
                                    tipo_registro,

                                "Estado Pago":
                                    p_estado,

                                "Concepto":
                                    p_concepto
                            }

                            if nombre_comprobante:

                                nuevo_pago["Concepto"] += (
                                    f" | Comprobante: "
                                    f"{nombre_comprobante}"
                                )

                            df_pagos_empleados = pd.concat(
                                [
                                    df_pagos_empleados,
                                    pd.DataFrame([nuevo_pago])
                                ],
                                ignore_index=True
                            )
                            
                            guardar_pago_en_neon(nuevo_pago)

                            df_pagos_empleados.to_csv(
                             ARCHIVO_PAGOS_EMPLEADOS,
                             index=False,
                             encoding="utf-8-sig"
                            )

                            st.success(
                                "✔ Movimiento registrado "
                                "correctamente."
                            )

                            st.rerun()

                else:

                    st.warning(
                        "No hay operarios registrados."
                    )

                                                # ==================================================
                # PAGO POR HECTÁREA
                # ==================================================

        elif tipo_carga == "🌾 Pago por hectárea":

                    st.markdown(
                        "### 🌾 Pago por hectárea"
                    )

                    st.info(
                        "Cargá una campaña y las hectáreas trabajadas. "
                        "El total se calcula automáticamente."
                    )

                    # ==========================================
                    # CAMPAÑA Y LOTE
                    # ==========================================

                    col1, col2 = st.columns(2)

                    with col1:

                        campaña_hectareas = st.text_input(
                            "🌾 Campaña",
                            placeholder="Ej: Campaña 2026/27",
                            key="campaña_pago_hectareas"
                        )

                    with col2:

                        lote_hectareas = st.text_input(
                            "📍 Lote",
                            placeholder="Ej: Lote 12",
                            key="lote_pago_hectareas"
                        )

                    # ==========================================
                    # FECHA
                    # ==========================================

                    usar_rango_fechas = st.checkbox(
                        "📅 Usar rango de fechas",
                        value=False,
                        key="usar_rango_fechas_hectareas"
                    )

                    if usar_rango_fechas:

                        col1, col2 = st.columns(2)

                        with col1:

                            fecha_desde_hectareas = st.date_input(
                                "📅 Fecha desde",
                                value=datetime.date.today(),
                                key="fecha_desde_pago_hectareas"
                            )

                        with col2:

                            fecha_hasta_hectareas = st.date_input(
                                "📅 Fecha hasta",
                                value=datetime.date.today(),
                                key="fecha_hasta_pago_hectareas"
                            )

                        fecha_pago_hectareas = fecha_desde_hectareas

                    else:

                        fecha_pago_hectareas = st.date_input(
                            "📅 Fecha",
                            value=datetime.date.today(),
                            key="fecha_pago_hectareas"
                        )

                        fecha_desde_hectareas = fecha_pago_hectareas
                        fecha_hasta_hectareas = fecha_pago_hectareas

                                        # ==========================================
                    # HECTÁREAS, VALOR Y PORCENTAJE
                    # ==========================================

                    col1, col2, col3 = st.columns(3)

                    with col1:

                        hectareas_trabajadas = st.number_input(
                            "🌱 Hectáreas trabajadas",
                            min_value=0.0,
                            step=0.1,
                            value=0.0,
                            key="hectareas_trabajadas"
                        )

                    with col2:

                        valor_hectarea = st.number_input(
                            "💰 Valor por hectárea ($ ARS)",
                            min_value=0.0,
                            step=100.0,
                            value=0.0,
                            key="valor_hectarea_pago"
                        )

                    with col3:

                        porcentaje_hectarea = st.number_input(
                            "📊 Porcentaje a cobrar (%)",
                            min_value=0.0,
                            max_value=100.0,
                            step=0.5,
                            value=5.0,
                            key="porcentaje_hectarea_pago"
                        )

                    # ==========================================
                    # CÁLCULO AUTOMÁTICO
                    # ==========================================

                    ganancia_total_hectareas = (
                        hectareas_trabajadas
                        * valor_hectarea
                    )

                    total_pagar_hectareas = (
                        ganancia_total_hectareas
                        * porcentaje_hectarea
                        / 100
                    )

                    col1, col2 = st.columns(2)

                    with col1:

                        st.metric(
                            "💵 Ganancia total",
                            f"$ {ganancia_total_hectareas:,.2f}"
                        )

                    with col2:

                        st.metric(
                            "💰 Total a pagar",
                            f"$ {total_pagar_hectareas:,.2f}"
                        )
                    # ==========================================
                    # ESTADO
                    # ==========================================

                    estado_pago_hectareas = st.selectbox(
                        "📌 Estado del pago",
                        [
                            "Pagado",
                            "Pendiente",
                            "Pago parcial"
                        ],
                        key="estado_pago_hectareas"
                    )

                    # ==========================================
                    # COMPROBANTE
                    # ==========================================

                    comprobantes_hectareas = st.file_uploader(
                     "📎 Comprobantes de pago (opcional)",
                     type=[
                          "pdf",
                          "png",
                          "jpg",
                          "jpeg",
                          "webp"
                        ],
                        accept_multiple_files=True,
                        key="comprobantes_pago_hectareas"
                        )

                    # ==========================================
                    # RESUMEN
                    # ==========================================

                    st.markdown("### 📋 Resumen")

                    st.write(
                        f"**Campaña:** "
                        f"{campaña_hectareas or '-'}"
                    )

                    st.write(
                        f"**Lote:** "
                        f"{lote_hectareas or '-'}"
                    )

                    if usar_rango_fechas:

                        st.write(
                            f"**Período:** "
                            f"{fecha_desde_hectareas.strftime('%d/%m/%Y')} "
                            f"al "
                            f"{fecha_hasta_hectareas.strftime('%d/%m/%Y')}"
                        )

                    else:

                        st.write(
                            f"**Fecha:** "
                            f"{fecha_pago_hectareas.strftime('%d/%m/%Y')}"
                        )

                    st.write(
                        f"**Hectáreas:** "
                        f"{hectareas_trabajadas:,.2f} ha"
                    )

                    st.write(
                        f"**Valor por hectárea:** "
                        f"$ {valor_hectarea:,.2f}"
                    )

                    st.write(
                        f"**Total a pagar:** "
                        f"**$ {total_pagar_hectareas:,.2f}**"
                    )

                    # ==========================================
                    # GUARDAR
                    # ==========================================

                    guardar_pago_hectareas = st.button(
                        "💾 Guardar pago por hectárea",
                        use_container_width=True,
                        key="btn_guardar_pago_hectareas"
                    )

                    if guardar_pago_hectareas:

                        # ======================================
                        # VALIDACIONES
                        # ======================================

                        if not campaña_hectareas.strip():

                            st.error(
                                "❌ Tenés que ingresar la campaña."
                            )
                            st.stop()

                        if not lote_hectareas.strip():

                            st.error(
                                "❌ Tenés que ingresar el lote."
                            )
                            st.stop()

                        if hectareas_trabajadas <= 0:

                            st.error(
                                "❌ Tenés que ingresar las hectáreas trabajadas."
                            )
                            st.stop()

                        if valor_hectarea <= 0:

                            st.error(
                                "❌ Tenés que ingresar el valor por hectárea."
                            )
                            st.stop()

                        if (
                            usar_rango_fechas
                            and fecha_hasta_hectareas
                            < fecha_desde_hectareas
                        ):

                            st.error(
                                "❌ La fecha hasta no puede ser anterior "
                                "a la fecha desde."
                            )
                            st.stop()

                        # ======================================
                        # GENERAR ID
                        # ======================================

                        if df_pagos_empleados.empty:

                            nuevo_id_hectareas = 1

                        else:

                            ids_hectareas = pd.to_numeric(
                                df_pagos_empleados["ID_Pago"],
                                errors="coerce"
                            ).dropna()

                            if ids_hectareas.empty:

                                nuevo_id_hectareas = 1

                            else:

                                nuevo_id_hectareas = (
                                    int(ids_hectareas.max()) + 1
                                )

                                                # ======================================
                        # GUARDAR COMPROBANTES
                        # ======================================

                        nombres_comprobantes_hectareas = []

                        if comprobantes_hectareas:

                            carpeta_comprobantes = (
                                "comprobantes_pagos"
                            )

                            os.makedirs(
                                carpeta_comprobantes,
                                exist_ok=True
                            )

                            for numero, comprobante in enumerate(
                                comprobantes_hectareas,
                                start=1
                            ):

                                extension = os.path.splitext(
                                    comprobante.name
                                )[1]

                                nombre_comprobante = (
                                    f"hectareas_"
                                    f"{nuevo_id_hectareas}_"
                                    f"{numero}"
                                    f"{extension}"
                                )

                                ruta_comprobante = os.path.join(
                                    carpeta_comprobantes,
                                    nombre_comprobante
                                )

                                with open(
                                    ruta_comprobante,
                                    "wb"
                                ) as archivo:

                                    archivo.write(
                                        comprobante.getbuffer()
                                    )

                                nombres_comprobantes_hectareas.append(
                                    nombre_comprobante
                                )
                        # ======================================
                        # FECHAS PARA GUARDAR
                        # ======================================

                        if usar_rango_fechas:

                            fecha_trabajo_guardada = (
                                f"{fecha_desde_hectareas}"
                                f" al "
                                f"{fecha_hasta_hectareas}"
                            )

                        else:

                            fecha_trabajo_guardada = str(
                                fecha_pago_hectareas
                            )

                        # ======================================
                        # NUEVO MOVIMIENTO
                        # ======================================

                        nuevo_pago_hectareas = {

                            "ID_Pago":
                                str(nuevo_id_hectareas),

                            "Fecha Pago":
                                str(
                                    datetime.date.today()
                                ),

                            "Nombre Empleado":
                                "Pago general por hectárea",

                            "Fecha Trabajo":
                                fecha_trabajo_guardada,

                            "Hora Entrada":
                                "",

                            "Hora Salida":
                                "",

                            "Horas Trabajadas":
                                0.0,

                            "Valor Hora":
                                0.0,

                            "Monto (ARS)":
                                round(
                                    total_pagar_hectareas,
                                    2
                                ),

                            "Tipo Registro":
                                "Pago por hectárea",

                            "Estado Pago":
                                estado_pago_hectareas,

                            "Concepto":
                            (
                              f"Campaña: "
                              f"{campaña_hectareas.strip()} "
                              f"| Lote: "
                              f"{lote_hectareas.strip()} "
                              f"| "
                              f"{hectareas_trabajadas:,.2f} ha "
                              f"x $ "
                              f"{valor_hectarea:,.2f}/ha "
                              f"| "
                              f"{porcentaje_hectarea:,.2f}%"
                            ),
                            "Porcentaje Bonificacion":
                                0.0,

                            "Monto Bonificacion (ARS)":
                                0.0,

                            "Porcentaje Descuento":
                                0.0,

                            "Monto Descuento (ARS)":
                                0.0,

                            "Monto Trabajado (ARS)":
                                round(
                                    total_pagar_hectareas,
                                    2
                                ),

                            "Monto Pagado (ARS)":
                                (
                                    round(
                                        total_pagar_hectareas,
                                        2
                                    )
                                    if estado_pago_hectareas
                                    == "Pagado"
                                    else 0.0
                                ),

                            "Monto Final Trabajo (ARS)":
                                round(
                                    total_pagar_hectareas,
                                    2
                                ),

                            "Adelanto Generado (ARS)":
                                0.0,

                            "Monto Compensado (ARS)":
                                0.0,

                            "Saldo Adelanto (ARS)":
                                0.0,

                            "Saldo Pendiente Pago (ARS)":
                                (
                                    round(
                                        total_pagar_hectareas,
                                        2
                                    )
                                    if estado_pago_hectareas
                                    != "Pagado"
                                    else 0.0
                                ),

                            "Comprobantes":
                             ", ".join(nombres_comprobantes_hectareas),

                            "PDF Liquidacion":
                                ""
                        }

                        # ======================================
                        # GUARDAR EN TABLA
                        # ======================================

                        df_pagos_empleados = pd.concat(
                            [
                                df_pagos_empleados,
                                pd.DataFrame(
                                    [nuevo_pago_hectareas]
                                )
                            ],
                            ignore_index=True
                        )

                        guardar_pago_en_neon(nuevo_pago_hectareas)

                        df_pagos_empleados.to_csv(
                            ARCHIVO_PAGOS_EMPLEADOS,
                            index=False,
                            encoding="utf-8-sig"
                        )

                        st.success(
                            "✅ Pago por hectárea guardado correctamente."
                        )

                        if nombres_comprobantes_hectareas:

                            st.success(
                                f"✅ Se guardaron "
                                f"{len(nombres_comprobantes_hectareas)} "
                                f"comprobante(s) correctamente."
                            )

                            st.markdown(
                                "### 📎 Comprobantes guardados"
                            )

                            for indice, nombre_archivo in enumerate(
                                nombres_comprobantes_hectareas,
                                start=1
                            ):

                                st.write(
                                    f"📎 Comprobante {indice}: "
                                    f"`{str(nombre_archivo)}`"
                                )
                                
        # ==================================================
        # LIQUIDACIÓN ESPECIAL POR HORAS TOTALES
        # ==================================================

        else:

                    st.markdown(
                        "### 📋 Liquidación por horas totales"
                    )

                    st.info(
                        "Esta modalidad permite liquidar varias horas juntas, "
                        "aplicando bonificaciones, descuentos, adelantos y saldos."
                    )

                    if not df_empleados.empty:

                        # ==========================================
                        # EMPLEADO
                        # ==========================================

                        emp_liquidacion = st.selectbox(
                            "👤 Empleado",
                            df_empleados["Nombre"].tolist(),
                            key="empleado_liquidacion_especial"
                        )
                        # Detectar cambio de empleado
                        empleado_actual = emp_liquidacion

                        if "empleado_liquidacion_anterior" not in st.session_state:
                          st.session_state["empleado_liquidacion_anterior"] = empleado_actual

                        elif st.session_state["empleado_liquidacion_anterior"] != empleado_actual:
                         st.session_state["empleado_liquidacion_anterior"] = empleado_actual

                         # Limpiar los valores anteriores
                         for clave in [
                         "horas_totales_liquidacion",
                         "valor_hora_total_liquidacion",
                         "porcentaje_bonificacion_liquidacion",
                         "porcentaje_descuento_liquidacion",
                         "monto_pagado_liquidacion"
                        ]:
                          if clave in st.session_state:
                             del st.session_state[clave]
                        # ==========================================
                        # FECHA DE LIQUIDACIÓN
                        # ==========================================

                        fecha_liquidacion = st.date_input(
                            "📅 Fecha de liquidación",
                            value=datetime.date.today(),
                            key="fecha_liquidacion_especial"
                        )

                        # ==========================================
                        # PERÍODO DE JORNADAS
                        # ==========================================

                        st.markdown(
                            "#### 🕐 Horas registradas en Mi Jornada"
                        )

                        col1, col2 = st.columns(2)

                        with col1:

                            fecha_desde_jornada = st.date_input(
                                "📅 Desde",
                                value=fecha_liquidacion,
                                key="fecha_desde_jornada_liquidacion"
                            )

                        with col2:

                            fecha_hasta_jornada = st.date_input(
                                "📅 Hasta",
                                value=fecha_liquidacion,
                                key="fecha_hasta_jornada_liquidacion"
                            )

                        # ==========================================
                        # OBTENER HORAS AUTOMÁTICAMENTE
                        # ==========================================

                        if fecha_hasta_jornada < fecha_desde_jornada:

                            st.error(
                                "❌ La fecha hasta no puede ser anterior "
                                "a la fecha desde."
                            )

                            horas_totales = 0.0

                        else:

                            horas_totales = obtener_horas_jornada_periodo(
                                emp_liquidacion,
                                fecha_desde_jornada,
                                fecha_hasta_jornada
                            )

                        # ==========================================
                        # MOSTRAR HORAS
                        # ==========================================

                        st.metric(
                            "⏱️ Horas totales registradas",
                            f"{horas_totales:.2f} h"
                        )

                        if horas_totales > 0:

                            st.success(
                                f"✅ Se encontraron "
                                f"**{horas_totales:.2f} horas** "
                                f"registradas para {emp_liquidacion}."
                            )

                        else:

                            st.warning(
                               "⚠️ No hay horas registradas en "
                               "Mi Jornada para el período seleccionado."
                           )

                        # ==========================================
                        # VALOR HORA
                        # ==========================================

                        valor_hora_total = st.number_input(
                            "💰 Valor por hora",
                            min_value=0.0,
                            step=100.0,
                            value=0.0,
                            key="valor_hora_total_liquidacion"
                        )

                        # ==========================================
                        # MONTO BASE
                        # ==========================================

                        monto_base_trabajado = (
                            horas_totales * valor_hora_total
                        )

                        st.metric(
                            "💵 Monto trabajado",
                            f"$ {monto_base_trabajado:,.2f}"
                        )

                        # ==========================================
                        # BONIFICACIÓN
                        # ==========================================

                        st.markdown("#### ➕ Bonificación")

                        porcentaje_bonificacion = st.number_input(
                            "Bonificación (%)",
                            min_value=0.0,
                            max_value=100.0,
                            step=1.0,
                            value=0.0,
                            key="porcentaje_bonificacion_liquidacion"
                        )

                        monto_bonificacion = (
                            monto_base_trabajado
                            * porcentaje_bonificacion
                            / 100
                        )

                        st.write(
                            f"Bonificación: "
                            f"**$ {monto_bonificacion:,.2f}**"
                        )

                        # ==========================================
                        # DESCUENTO
                        # ==========================================

                        st.markdown("#### ➖ Descuento")

                        porcentaje_descuento = st.number_input(
                            "Descuento (%)",
                            min_value=-100.0,
                            max_value=100.0,
                            step=1.0,
                            value=0.0,
                            key="porcentaje_descuento_liquidacion"
                        )

                        monto_descuento = (
                            monto_base_trabajado
                            * porcentaje_descuento
                            / -100
                        )

                        st.write(
                            f"Descuento: "
                            f"**$ {monto_descuento:,.2f}**"
                        )

                        # ==========================================
                        # TOTAL FINAL DEL TRABAJO
                        # ==========================================

                        monto_final_trabajo = (
                            monto_base_trabajado
                            + monto_bonificacion
                            - monto_descuento
                        )

                        st.metric(
                            "💰 Total final del trabajo",
                            f"$ {monto_final_trabajo:,.2f}"
                        )

                        # ==========================================
                        # SALDOS ANTERIORES
                        # ==========================================

                        saldos = obtener_saldos_empleado(
                            df_pagos_empleados,
                            emp_liquidacion
                        )

                        saldo_adelanto_anterior = float(
                            saldos["adelanto"]
                        )

                        saldo_pendiente_anterior = float(
                            saldos["pendiente"]
                        )

                        st.markdown(
                            "#### 📊 Saldos anteriores"
                        )

                        col1, col2 = st.columns(2)

                        with col1:

                            st.metric(
                                "Adelanto pendiente",
                                f"$ {saldo_adelanto_anterior:,.2f}"
                            )

                        with col2:

                            st.metric(
                                "Pago pendiente",
                                f"$ {saldo_pendiente_anterior:,.2f}"
                            )

                        # ==========================================
                        # TOTAL ADEUDADO
                        # ==========================================

                        total_debido = (
                            saldo_pendiente_anterior
                            + monto_final_trabajo
                        )

                        # ==========================================
                        # COMPENSAR ADELANTO
                        # ==========================================

                        monto_compensado = min(
                            saldo_adelanto_anterior,
                            total_debido
                        )

                        monto_neto_a_pagar = (
                            total_debido
                            - monto_compensado
                        )

                        st.markdown(
                            "#### 🧮 Compensación"
                        )

                        col1, col2, col3 = st.columns(3)

                        with col1:

                            st.metric(
                                "Total adeudado",
                                f"$ {total_debido:,.2f}"
                            )

                        with col2:

                            st.metric(
                                "Adelanto compensado",
                                f"$ {monto_compensado:,.2f}"
                            )

                        with col3:

                            st.metric(
                                "Neto a pagar",
                                f"$ {monto_neto_a_pagar:,.2f}"
                            )

                        # ==========================================
                        # MONTO REALMENTE PAGADO
                        # ==========================================

                        st.markdown(
                            "#### 💵 Pago realizado"
                        )

                        monto_pagado = st.number_input(
                            "💵 Monto realmente pagado",
                            min_value=0.0,
                            step=100.0,
                            value=0.0,
                            key="monto_pagado_liquidacion"
                        )

                        # ==========================================
                        # DIFERENCIA
                        # ==========================================

                        diferencia_pago = (
                            monto_pagado
                            - monto_neto_a_pagar
                        )

                        if diferencia_pago < 0:

                            saldo_pendiente_nuevo = abs(
                                diferencia_pago
                            )

                            adelanto_nuevo = 0.0

                        elif diferencia_pago > 0:

                            saldo_pendiente_nuevo = 0.0

                            adelanto_nuevo = (
                                diferencia_pago
                            )

                        else:

                            saldo_pendiente_nuevo = 0.0

                            adelanto_nuevo = 0.0

                        # ==========================================
                        # SALDO FINAL ADELANTO
                        # ==========================================

                        saldo_adelanto_final = (
                            saldo_adelanto_anterior
                            - monto_compensado
                            + adelanto_nuevo
                        )

                        saldo_adelanto_final = max(
                            saldo_adelanto_final,
                            0.0
                        )

                        # ==========================================
                        # RESULTADO
                        # ==========================================

                        st.markdown(
                            "#### 📌 Resultado de la liquidación"
                        )

                        col1, col2, col3 = st.columns(3)

                        with col1:

                            st.metric(
                                "Adelanto final",
                                f"$ {saldo_adelanto_final:,.2f}"
                            )

                        with col2:

                            st.metric(
                                "Pendiente de pago",
                                f"$ {saldo_pendiente_nuevo:,.2f}"
                            )

                        with col3:

                            st.metric(
                                "Realmente pagado",
                                f"$ {monto_pagado:,.2f}"
                            )

                        # ==========================================
                        # ESTADO Y CONCEPTO
                        # ==========================================

                        col1, col2 = st.columns(2)

                        with col1:

                            estado_liquidacion = st.selectbox(
                                "📌 Estado",
                                [
                                    "Pagado",
                                    "Pago parcial",
                                    "Pendiente"
                                ],
                                key="estado_liquidacion_especial"
                            )

                        with col2:

                            concepto_liquidacion = st.text_input(
                                "📝 Concepto",
                                value="Liquidación por horas totales",
                                key="concepto_liquidacion_especial"
                            )

                        # ==========================================
                        # COMPROBANTES
                        # ==========================================

                        archivos_comprobantes = st.file_uploader(
                            "📎 Comprobantes",
                            accept_multiple_files=True,
                            type=[
                                "pdf",
                                "png",
                                "jpg",
                                "jpeg",
                                "webp"
                            ],
                            key="comprobantes_liquidacion_especial"
                        )

                        # ==========================================
                        # RESUMEN
                        # ==========================================

                        st.markdown("### 📋 Resumen")

                        st.write(
                            f"**Empleado:** {emp_liquidacion}"
                        )

                        st.write(
                            f"**Horas:** {horas_totales:,.2f}"
                        )

                        st.write(
                            f"**Valor hora:** "
                            f"$ {valor_hora_total:,.2f}"
                        )

                        st.write(
                            f"**Monto trabajado:** "
                            f"$ {monto_base_trabajado:,.2f}"
                        )

                        st.write(
                            f"**Bonificación:** "
                            f"$ {monto_bonificacion:,.2f}"
                        )

                        st.write(
                            f"**Descuento:** "
                            f"$ {monto_descuento:,.2f}"
                        )

                        st.write(
                            f"**Total final trabajo:** "
                            f"$ {monto_final_trabajo:,.2f}"
                        )

                        st.write(
                            f"**Adelanto compensado:** "
                            f"$ {monto_compensado:,.2f}"
                        )

                        st.write(
                            f"**Neto a pagar:** "
                            f"$ {monto_neto_a_pagar:,.2f}"
                        )

                        st.write(
                            f"**Monto realmente pagado:** "
                            f"$ {monto_pagado:,.2f}"
                        )

                        st.write(
                            f"**Adelanto final:** "
                            f"$ {saldo_adelanto_final:,.2f}"
                        )

                        st.write(
                            f"**Pendiente de pago:** "
                            f"$ {saldo_pendiente_nuevo:,.2f}"
                        )

                                                # ==========================================
                        # GUARDAR LIQUIDACIÓN
                        # ==========================================

                        guardar_liquidacion = st.button(
                            "💾 Guardar liquidación",
                            use_container_width=True,
                            key="btn_guardar_liquidacion_especial"
                        )

                        if guardar_liquidacion:

                            # ======================================
                            # VALIDACIONES
                            # ======================================

                            if horas_totales <= 0:
                                st.error(
                                    "❌ Tenés que ingresar las horas trabajadas."
                                )
                                st.stop()

                            if valor_hora_total <= 0:
                                st.error(
                                    "❌ Tenés que ingresar el valor por hora."
                                )
                                st.stop()

                            # ======================================
                            # GENERAR ID
                            # ======================================

                            if df_pagos_empleados.empty:

                                nuevo_id = 1

                            else:

                                ids = pd.to_numeric(
                                    df_pagos_empleados["ID_Pago"],
                                    errors="coerce"
                                )

                                ids = ids.dropna()

                                if ids.empty:
                                    nuevo_id = 1
                                else:
                                    nuevo_id = int(ids.max()) + 1

                            # ======================================
                            # COMPROBANTES
                            # ======================================

                            nombres_comprobantes = guardar_comprobantes(
                                archivos_comprobantes,
                                nuevo_id
                            )
                            st.write("DEBUG - ID:", nuevo_id)
                            st.write("DEBUG - Archivos recibidos:", archivos_comprobantes)
                            st.write("DEBUG - Nombres guardados:", nombres_comprobantes)
                            st.write(
                             "DEBUG - Carpeta existe:",
                             os.path.exists("comprobantes_pagos")
                            )

                            if os.path.exists("comprobantes_pagos"):
                                st.write(
                                 "DEBUG - Archivos en carpeta:",
                                 os.listdir("comprobantes_pagos")
                            )
                            
                            # ======================================
                            # GENERAR PDF
                            # ======================================

                            pdf_bytes = generar_pdf_liquidacion(
                                nuevo_id=nuevo_id,
                                empleado=emp_liquidacion,
                                fecha=fecha_liquidacion,
                                horas=horas_totales,
                                valor_hora=valor_hora_total,
                                monto_trabajado=monto_base_trabajado,
                                bonificacion=monto_bonificacion,
                                descuento=monto_descuento,
                                monto_final=monto_final_trabajo,
                                adelanto_anterior=saldo_adelanto_anterior,
                                pendiente_anterior=saldo_pendiente_anterior,
                                compensado=monto_compensado,
                                neto_pagar=monto_neto_a_pagar,
                                monto_pagado=monto_pagado,
                                adelanto_final=saldo_adelanto_final,
                                pendiente_final=saldo_pendiente_nuevo,
                                concepto=concepto_liquidacion
                            )

                            nombre_pdf = (
                                f"liquidacion_{nuevo_id}.pdf"
                            )

                            # ======================================
                            # GUARDAR PDF EN CARPETA
                            # ======================================

                            carpeta_pdfs = "liquidaciones_pdf"

                            os.makedirs(
                                carpeta_pdfs,
                                exist_ok=True
                            )

                            ruta_pdf = os.path.join(
                                carpeta_pdfs,
                                nombre_pdf
                            )

                            with open(
                                ruta_pdf,
                                "wb"
                            ) as archivo_pdf:

                                archivo_pdf.write(pdf_bytes)

                            # ======================================
                            # NUEVO MOVIMIENTO
                            # ======================================

                            nuevo_pago = {

                                "ID_Pago":
                                    str(nuevo_id),

                                "Fecha Pago":
                                    str(fecha_liquidacion),

                                "Nombre Empleado":
                                    emp_liquidacion,

                                "Fecha Trabajo":
                                    str(fecha_liquidacion),

                                "Hora Entrada":
                                    "",

                                "Hora Salida":
                                    "",

                                "Horas Trabajadas":
                                    round(
                                        horas_totales,
                                        2
                                    ),

                                "Valor Hora":
                                    round(
                                        valor_hora_total,
                                        2
                                    ),

                                "Monto (ARS)":
                                    round(
                                        monto_pagado,
                                        2
                                    ),

                                "Tipo Registro":
                                    "Liquidación / Pago",

                                "Estado Pago":
                                    estado_liquidacion,

                                "Concepto":
                                    concepto_liquidacion,

                                "Porcentaje Bonificacion":
                                    round(
                                        porcentaje_bonificacion,
                                        2
                                    ),

                                "Monto Bonificacion (ARS)":
                                    round(
                                        monto_bonificacion,
                                        2
                                    ),

                                "Porcentaje Descuento":
                                    round(
                                        porcentaje_descuento,
                                        2
                                    ),

                                "Monto Descuento (ARS)":
                                    round(
                                        monto_descuento,
                                        2
                                    ),

                                "Monto Trabajado (ARS)":
                                    round(
                                        monto_base_trabajado,
                                        2
                                    ),

                                "Monto Pagado (ARS)":
                                    round(
                                        monto_pagado,
                                        2
                                    ),

                                "Monto Final Trabajo (ARS)":
                                    round(
                                        monto_final_trabajo,
                                        2
                                    ),

                                "Adelanto Generado (ARS)":
                                    round(
                                        adelanto_nuevo,
                                        2
                                    ),

                                "Monto Compensado (ARS)":
                                    round(
                                        monto_compensado,
                                        2
                                    ),

                                "Saldo Adelanto (ARS)":
                                    round(
                                        saldo_adelanto_final,
                                        2
                                    ),

                                "Saldo Pendiente Pago (ARS)":
                                    round(
                                        saldo_pendiente_nuevo,
                                        2
                                    ),

                                "Comprobantes":
                                    ", ".join(
                                        str(x)
                                        for x in nombres_comprobantes
                                    ),

                                "PDF Liquidacion":
                                    nombre_pdf,

                                "Liquidar Jornadas":
                                    True,

                                "Fecha Desde Jornadas":
                                    fecha_desde_jornada,

                                "Fecha Hasta Jornadas":
                                    fecha_hasta_jornada
                            }        

                            # ======================================
                            # AGREGAR A LA TABLA
                            # ======================================

                            df_pagos_empleados = pd.concat(
                                [
                                    df_pagos_empleados,
                                    pd.DataFrame([nuevo_pago])
                                ],
                                ignore_index=True
                            )

                            guardar_pago_en_neon(nuevo_pago)

                            # ======================================
                            # GUARDAR CSV
                            # ======================================

                            df_pagos_empleados.to_csv(
                                ARCHIVO_PAGOS_EMPLEADOS,
                                index=False,
                                encoding="utf-8-sig"
                            )

                            # ======================================
                            # GUARDAR ID PARA MOSTRAR CONFIRMACIÓN
                            # ======================================

                            st.session_state[
                                "ultima_liquidacion_guardada"
                            ] = nuevo_id

                            st.session_state[
                                "ultimo_pdf_liquidacion"
                            ] = pdf_bytes

                            st.session_state[
                                "ultimo_nombre_pdf"
                            ] = nombre_pdf

                            st.success(
                                f"✅ Liquidación #{nuevo_id} "
                                f"guardada correctamente."
                            )

                            st.download_button(
                                label="📄 Descargar liquidación",
                                data=pdf_bytes,
                                file_name=nombre_pdf,
                                mime="application/pdf",
                                key=f"descargar_liquidacion_{nuevo_id}",
                                use_container_width=True
                            )

                            # ======================================
                            # MOSTRAR COMPROBANTES RECIÉN GUARDADOS
                            # ======================================
                            if nombres_comprobantes:

                                st.markdown(
                                    "### 📎 Comprobante de la liquidación"
                                )

                                for nombre_comprobante in nombres_comprobantes:

                                    ruta_comprobante = os.path.join(
                                        "comprobantes_pagos",
                                        nombre_comprobante
                                    )

                                    if os.path.isfile(
                                        ruta_comprobante
                                    ):

                                        with open(
                                            ruta_comprobante,
                                            "rb"
                                        ) as archivo:

                                            datos_comprobante = (
                                                archivo.read()
                                            )

                                        st.download_button(
                                            label=(
                                                "📎 Ver / descargar "
                                                f"{nombre_comprobante}"
                                            ),
                                            data=datos_comprobante,
                                            file_name=(
                                                nombre_comprobante
                                            ),
                                            key=(
                                                f"comprobante_guardado_"
                                                f"{nuevo_id}_"
                                                f"{nombre_comprobante}"
                                            ),
                                            use_container_width=True
                                        )

                                    else:

                                        st.error(
                                            f"❌ El comprobante "
                                            f"{nombre_comprobante} "
                                            f"no se encuentra en la carpeta."
                                        )
# ----------------------------------------------------
# PESTAÑA: RENDICIÓN POR OPERARIO
# ----------------------------------------------------

if menu == "📋 RENDICIÓN POR OPERARIO":

    st.header("📋 Historial de Cuenta por Operario")

    # ==========================================
    # FILTRO DE PRIVACIDAD
    # ==========================================

    # Un operario solamente puede ver su propia cuenta.
    # Dueño, Administrador, Encargado y Contador
    # pueden seleccionar cualquier operario.

    if tiene_rol("Operario") and not tiene_rol(
        "Dueño",
        "Administrador",
        "Encargado",
        "Contador"
    ):

        lista_para_filtrar = [nombre_actual]

        st.info(
            f"👤 Visualizando la cuenta de: **{nombre_actual}**"
        )

    else:

        lista_para_filtrar = (
            df_empleados["Nombre"].tolist()
            if not df_empleados.empty
            else ["No hay personal registrado"]
        )

    # ==========================================
    # SELECCIONAR OPERARIO
    # ==========================================

    op_filtro = st.selectbox(
        "Seleccionar Operario para revisar:",
        lista_para_filtrar
    )

    # ==========================================
    # FILTRAR MOVIMIENTOS
    # ==========================================

    if not df_pagos_empleados.empty:

        df_op = df_pagos_empleados[
            df_pagos_empleados["Nombre Empleado"] == op_filtro
        ]

    else:

        df_op = pd.DataFrame()

    # ==========================================
    # COLUMNAS
    # ==========================================

    col_r1, col_r2 = st.columns(2)

    # ==========================================
    # LIQUIDACIONES Y PAGOS
    # ==========================================

    with col_r1:

        st.markdown(
            "### 💰 LIQUIDACIONES Y PAGOS EN EFECTIVO"
        )

        if not df_op.empty:

            df_pagos = df_op[
                df_op["Tipo Registro"] == "Liquidación / Pago"
            ]

            if not df_pagos.empty:

                st.dataframe(
             df_pagos[
            [
             "Fecha Trabajo",
             "Hora Entrada",
             "Hora Salida",
             "Horas Trabajadas",
             "Valor Hora",
             "Monto Trabajado (ARS)",
             "Porcentaje Bonificacion",
             "Monto Bonificacion (ARS)",
             "Porcentaje Descuento",
             "Monto Descuento (ARS)",
             "Monto Final Trabajo (ARS)",
             "Monto Pagado (ARS)",
             "Adelanto Generado (ARS)",
             "Monto Compensado (ARS)",
             "Saldo Adelanto (ARS)",
             "Saldo Pendiente Pago (ARS)",
             "Estado Pago",
             "Concepto"
            ]
        ],
         use_container_width=True,
         hide_index=True
        )
                # Total de pagos
                total_pagos = df_pagos[
                    "Monto (ARS)"
                ].sum()

                st.metric(
                    "💰 Total Liquidaciones",
                    f"$ {total_pagos:,.2f}"
                )
                                # ==========================================
                # COMPROBANTES AUTOMÁTICOS DE LIQUIDACIÓN
                # ==========================================

                st.markdown(
                    "### 📄 Comprobantes de liquidación"
                )

                pdfs_mostrados = False

                for _, fila_pago in df_pagos.iterrows():

                    nombre_pdf = fila_pago.get(
                        "PDF Liquidacion",
                        ""
                    )

                    if pd.isna(nombre_pdf):

                        nombre_pdf = ""

                    nombre_pdf = str(
                        nombre_pdf
                    ).strip()

                    if not nombre_pdf:

                        continue

                    # ==========================================
                    # OBTENER ID DEL PAGO
                    # ==========================================

                    id_pago = fila_pago.get(
                        "ID_Pago",
                        ""
                    )

                    id_pago = str(
                        id_pago
                    ).strip()

                    datos_pdf = None

                    # ==========================================
                    # BUSCAR PDF DIRECTAMENTE EN NEON
                    # ==========================================

                    if id_pago:

                        conn_pdf = None
                        cursor_pdf = None

                        try:

                            conn_pdf = get_conn()
                            cursor_pdf = conn_pdf.cursor()

                            cursor_pdf.execute(
                                """
                                SELECT
                                    pdf_liquidacion_data
                                FROM pagos_empleados
                                WHERE id_pago = %s
                                  AND pdf_liquidacion_data IS NOT NULL
                                ORDER BY id DESC
                                LIMIT 1
                                """,
                                (id_pago,)
                            )

                            resultado_pdf = (
                                cursor_pdf.fetchone()
                            )

                            if resultado_pdf:

                                datos_pdf = bytes(
                                    resultado_pdf[0]
                                )

                        except Exception as e:

                            st.error(
                                f"❌ Error buscando PDF de "
                                f"liquidación {id_pago}: {e}"
                            )

                        finally:

                            if cursor_pdf:

                                cursor_pdf.close()

                            if conn_pdf:

                                conn_pdf.close()

                    # ==========================================
                    # MOSTRAR PDF
                    # ==========================================

                    if datos_pdf:

                        pdfs_mostrados = True

                        id_numerico = pd.to_numeric(
                            id_pago,
                            errors="coerce"
                        )

                        if pd.notna(id_numerico):

                            id_liquidacion = str(
                                int(id_numerico)
                            )

                        else:

                            id_liquidacion = id_pago

                        st.markdown(
                            f"**📋 Liquidación "
                            f"#{id_liquidacion}**"
                        )

                        st.download_button(
                            label=(
                                "📄 Ver / descargar "
                                "comprobante de liquidación"
                            ),
                            data=datos_pdf,
                            file_name=nombre_pdf,
                            mime="application/pdf",
                            key=(
                                "pdf_liquidacion_neon_"
                                f"{id_liquidacion}_"
                                f"{nombre_pdf}"
                            ),
                            use_container_width=True
                        )

                    else:

                        st.warning(
                            f"⚠️ No se encontró el PDF "
                            f"de la liquidación #{id_pago}."
                        )

                if not pdfs_mostrados:

                    st.info(
                        "ℹ️ No hay comprobantes de "
                        "liquidación disponibles."
                    )

    # ==========================================
    # VALES Y REINTEGROS
    # ==========================================

    with col_r2:

        st.markdown(
            "### 🔧 VALES Y REINTEGROS (GASTOS A RENDIR)"
        )

        if not df_op.empty:

            df_reintegros = df_op[
                df_op["Tipo Registro"]
                == "Reintegro / Devolución"
            ]

            if not df_reintegros.empty:

                st.dataframe(
                    df_reintegros[
                        [
                            "Fecha Pago",
                            "Monto (ARS)",
                            "Estado Pago",
                            "Concepto"
                        ]
                    ],
                    use_container_width=True,
                    hide_index=True
                )

                # Total de reintegros
                total_reintegros = df_reintegros[
                    "Monto (ARS)"
                ].sum()

                st.metric(
                    "🔧 Total Reintegros",
                    f"$ {total_reintegros:,.2f}"
                )

            else:

                st.info(
                    "No hay registros de reintegros o vales."
                )

        else:

            st.info("Sin movimientos.")
if menu == "💰 INGRESOS POR TRABAJOS":

    pantalla_ingresos()

if menu == "🏦 MOVIMIENTOS BANCARIOS":

    pantalla_movimientos_bancarios()

if menu == "👥 CLIENTES":

    pantalla_clientes()
if menu == "🧾 FACTURACIÓN":

    pantalla_facturacion()

if menu == "🛠 SERVICIOS":

        pantalla_servicios()

if menu == "🌱 CAMPAÑAS AGRÍCOLAS":
    pantalla_campanas()

if menu == "🔧 MANTENIMIENTO DE MAQUINARIA":

    pantalla_mantenimiento()

if menu == "⛽ CONTROL DE COMBUSTIBLE":

    pantalla_combustible()

if menu == "📅 AGENDA Y VENCIMIENTOS":

    pantalla_agenda()

if menu == "⚙ ADMINISTRACIÓN":

    if not tiene_rol("Dueño", "Administrador"):

        st.error("No tiene permisos.")

        st.stop()

    pantalla_administracion()

if menu == "👑 PANEL DEL DUEÑO":

    if not tiene_rol("Dueño"):

        st.error("Solo acceso del dueño")

        st.stop()

    pantalla_panel_dueno()
    
# ==========================================
# NOTIFICACIONES
# ==========================================

if menu == "🔔 NOTIFICACIONES":

    st.header("🔔 Notificaciones")

    cantidad = contar_notificaciones_no_leidas()

    if cantidad > 0:

        st.info(
            f"📬 Tenés **{cantidad} "
            f"notificación(es) sin leer**."
        )

    else:

        st.success(
            "✅ No tenés notificaciones pendientes."
        )

    st.divider()

    mostrar_notificaciones()

# ----------------------------------------------------
# PESTAÑA: SEGUROS Y COBERTURAS
# ----------------------------------------------------
if menu == "🛡 SEGUROS Y COBERTURAS":
    if not tiene_rol("Dueño", "Administrador"):
        st.error("No tiene permisos.")
        st.stop()
        
    from operaciones_db import (
        cargar_seguros_desde_neon,
        guardar_seguro_neon,
        eliminar_seguro_neon,
    )    

    st.header("🛡 Control de Pólizas y Seguros")

    try:
        df_seguros = cargar_seguros_desde_neon()
    except Exception as e:
        st.error(f"No se pudieron cargar los seguros desde Neon: {e}")
        st.stop()

    with st.form("form_seguros", clear_on_submit=True):
        s1, s2, s3 = st.columns(3)

        with s1:
            seg_comp = st.text_input("Compañía Aseguradora")
            seg_tipo = st.selectbox(
                "Tipo Cobertura",
                [
                    "Maquinaria Agrícola",
                    "Granizo / Multiriesgo",
                    "Responsabilidad Civil",
                    "Otros",
                ],
            )

        with s2:
            seg_bien = st.text_input("Bien Asegurado")
            seg_venc = st.date_input(
                "Vencimiento",
                value=datetime.date.today(),
            )

        with s3:
            seg_monto = st.number_input(
                "Monto Cuota ($ ARS)",
                min_value=0.0,
            )
            seg_estado = st.radio(
                "Estado:",
                ["Pagado", "Pendiente"],
                horizontal=True,
            )

        btn_seguro = st.form_submit_button("💾 Archivar")

    if btn_seguro:
        if not seg_comp.strip():
            st.warning("Ingresá la compañía aseguradora.")
        elif not seg_bien.strip():
            st.warning("Ingresá el bien asegurado.")
        elif seg_monto <= 0:
            st.warning("El monto debe ser mayor que cero.")
        else:
            nuevo_seg = {
                "ID_Seguro": (
                    "seg_"
                    + datetime.datetime.now().strftime("%Y%m%d%H%M%S%f")
                ),
                "Compañía": seg_comp.strip(),
                "Tipo Cobertura": seg_tipo,
                "Bien Asegurado": seg_bien.strip(),
                "Vencimiento": seg_venc.strftime("%Y-%m-%d"),
                "Monto Prima (ARS)": seg_monto,
                "Estado Pago": seg_estado,
            }

            if guardar_seguro_neon(nuevo_seg):
                st.success("✅ Seguro archivado correctamente en Neon.")
                st.rerun()
            else:
                st.error(
                    "No se pudo guardar el seguro. "
                    "Revisá el mensaje de error anterior."
                )

    st.divider()
    st.subheader("📋 Seguros registrados")

    try:
        df_seguros = cargar_seguros_desde_neon()
    except Exception as e:
        st.error(f"No se pudieron actualizar los seguros: {e}")
        st.stop()

    if df_seguros.empty:
        st.info("Todavía no hay seguros registrados.")
    else:
        st.dataframe(
            df_seguros.drop(columns=["ID_Seguro"]),
            use_container_width=True,
            hide_index=True,
        )

        st.subheader("🗑️ Eliminar un seguro")

        for _, fila in df_seguros.iterrows():
            id_seguro = str(fila["ID_Seguro"])

            c_info, c_boton = st.columns([5, 1])

            with c_info:
                st.write(
                    f"**{fila['Compañía']}** | "
                    f"{fila['Bien Asegurado']} | "
                    f"Vence: {fila['Vencimiento']} | "
                    f"$ {float(fila['Monto Prima (ARS)'] or 0):,.2f} | "
                    f"{fila['Estado Pago']}"
                )

            with c_boton:
                if st.button(
                    "🗑️ Borrar",
                    key=f"borrar_seguro_{id_seguro}",
                ):
                    if eliminar_seguro_neon(id_seguro):
                        st.success("Seguro eliminado correctamente.")
                        st.rerun()
                    else:
                        st.error("No se pudo eliminar el seguro.")
# ----------------------------------------------------
# PESTAÑA SECRETA: CONTROL DE ERRORES
# ----------------------------------------------------

if menu == "🗄 CONTROL DE ERRORES":

    if not tiene_rol("Dueño"):
        st.error("Solo el dueño puede ingresar.")
        st.stop()

    st.header("🗄 Panel exclusivo de borrado (Solo Dueño)")

    sub_g, sub_i, sub_p, sub_s = st.tabs(
        [
            "Gastos",
            "Ingresos",
            "Pagos Personal",
            "Seguros"
        ]
    )

        # ==========================================
    # GASTOS
    # ==========================================

    with sub_g:

        if not df_facturas.empty:

            for idx, fila in df_facturas.copy().iterrows():

                c_i, c_b = st.columns([6, 1])

                with c_i:

                    st.write(
                        f"📅 {fila['Fecha Registro']} | "
                        f"*{fila['Proveedor']}* | "
                        f"**$ {fila['Monto Original']:,.2f}**"
                    )

                with c_b:

                    if st.button(
                        "🗑 Borrar",
                        key=f"b_fac_{fila['ID']}_{idx}"
                    ):

                        id_gasto_borrar = str(
                            fila["ID"]
                        )

                        conn = None
                        cursor = None

                        try:

                            conn = get_conn()
                            cursor = conn.cursor()

                            cursor.execute(
                                """
                                DELETE FROM gastos_comerciales
                                WHERE id_gasto = %s
                                """,
                                (id_gasto_borrar,)
                            )

                            conn.commit()

                        except Exception as e:

                            if conn:
                                conn.rollback()

                            st.error(
                                f"❌ No se pudo eliminar el gasto de Neon: {e}"
                            )

                            st.stop()

                        finally:

                            if cursor:
                                cursor.close()

                            if conn:
                                conn.close()

                        df_facturas = (
                            df_facturas[
                                df_facturas["ID"].astype(str)
                                != id_gasto_borrar
                            ]
                            .reset_index(drop=True)
                        )

                        df_facturas.to_csv(
                            "datos_facturas.csv",
                            index=False
                        )

                        st.success(
                            "✅ Gasto eliminado correctamente de Neon."
                        )

                        st.rerun()

        else:

            st.info(
                "No hay gastos registrados."
            )
    # ==========================================
    # INGRESOS
    # ==========================================

    with sub_i:

        if not df_ingresos.empty:

            for idx, fila in df_ingresos.copy().iterrows():

                c_i, c_b = st.columns([6, 1])

                with c_i:

                    st.write(
                        f"📅 {fila['Fecha']} | "
                        f"Cliente: *{fila['Cliente']}* | "
                        f"**$ {fila['Monto Total (ARS)']:,.2f}**"
                    )

                with c_b:

                    if st.button(
                        "🗑 Borrar",
                        key=f"b_ing_{fila['ID_Ingreso']}_{idx}"
                    ):

                        df_ingresos = df_ingresos.drop(idx)

                        df_ingresos.to_csv(
                            "registro_ingresos.csv",
                            index=False
                        )

                        st.success("Ingreso eliminado.")

                        st.rerun()

        else:

            st.info("No hay ingresos registrados.")

    # ==========================================
    # PAGOS PERSONAL
    # ==========================================

    with sub_p:

        if df_pagos_empleados.empty:

            st.info("No hay movimientos de personal.")

        else:

            for idx, fila in df_pagos_empleados.copy().iterrows():

                c_i, c_b = st.columns([6, 1])

                with c_i:

                    st.write(
                        f"📅 {fila['Fecha Pago']} | "
                        f"Operario: *{fila['Nombre Empleado']}* | "
                        f"**$ {fila['Monto (ARS)']:,.2f}**"
                    )

                with c_b:

                    boton_borrar = st.button(
                        "🗑 Borrar",
                        key=f"b_emp_{fila['ID_Pago']}_{idx}"
                    )

                if boton_borrar:

                    id_pago_borrar = str(
                        fila["ID_Pago"]
                    )

                # ==========================================
                # BORRAR DE NEON
                # ==========================================

                conn = None
                cursor = None

                try:

                    conn = get_conn()
                    cursor = conn.cursor()

                    cursor.execute(
                        """
                        DELETE FROM pagos_empleados
                        WHERE id_pago = %s
                        """,
                        (id_pago_borrar,)
                    )

                    conn.commit()

                except Exception as e:

                    if conn:
                        conn.rollback()

                    st.error(
                        f"❌ No se pudo eliminar de Neon: {e}"
                    )

                    if cursor:
                        cursor.close()

                    if conn:
                        conn.close()

                    st.stop()

                finally:

                    if cursor:
                        cursor.close()

                    if conn:
                        conn.close()

                # ==========================================
                # ELIMINAR DE LA TABLA EN MEMORIA
                # ==========================================

                df_pagos_empleados = (
                    df_pagos_empleados[
                        df_pagos_empleados["ID_Pago"].astype(str)
                        != id_pago_borrar
                    ]
                    .reset_index(drop=True)
                )

                # ==========================================
                # ACTUALIZAR CSV DE RESPALDO
                # ==========================================

                df_pagos_empleados.to_csv(
                    "registro_pagos_empleados.csv",
                    index=False,
                    encoding="utf-8-sig"
                )

                st.success(
                    "✅ Movimiento eliminado correctamente de Neon."
                )

                st.rerun()

    # ==========================================
    # SEGUROS
    # ==========================================

    with sub_s:

        if not df_seguros.empty:

            for idx, fila in df_seguros.copy().iterrows():

                c_i, c_b = st.columns([6, 1])

                with c_i:

                    st.write(
                        f"🛡 {fila['Compañía']} | "
                        f"Bien: *{fila['Bien Asegurado']}* | "
                        f"**$ {fila['Monto Prima (ARS)']:,.2f}**"
                    )

                with c_b:

                    if st.button(
                        "🗑 Borrar",
                        key=f"b_seg_{fila['ID_Seguro']}_{idx}"
                    ):

                        df_seguros = df_seguros.drop(idx)

                        df_seguros.to_csv(
                            "registro_seguros.csv",
                            index=False
                        )

                        st.success("Seguro eliminado.")

                        st.rerun()